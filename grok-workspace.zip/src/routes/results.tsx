import { useEffect, useState } from "react";
import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { findUnit } from "@/data/curriculum";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import {
  getDesk,
  reviewAttempt,
  type AttemptSummary,
  type SmsMessage,
  type StudentProfile,
} from "@/lib/academy.functions";
import { gradeBand } from "@/lib/student-rules";
import { PhoneCard, Shell, formatWhen, smsStatus } from "@/components/shell";

export const Route = createFileRoute("/results")({
  head: () => ({ meta: [{ title: "النتائج · SCI" }] }),
  component: ResultsPage,
});

type Review = Awaited<ReturnType<typeof reviewAttempt>>;

function ResultsPage() {
  const { user, isPending } = useCurrentUserState();
  const [profile, setProfile] = useState<StudentProfile | null | undefined>(undefined);
  const [attempts, setAttempts] = useState<AttemptSummary[]>([]);
  const [messages, setMessages] = useState<SmsMessage[]>([]);
  const [openId, setOpenId] = useState<number | null>(null);
  const [review, setReview] = useState<Review | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    let cancel = false;
    getDesk()
      .then((desk) => {
        if (cancel) return;
        setProfile(desk.profile);
        setAttempts(desk.attempts);
        setMessages(desk.messages);
      })
      .catch((cause: unknown) => {
        if (!cancel) setError(cause instanceof Error ? cause.message : "تعذر التحميل");
      });
    return () => {
      cancel = true;
    };
  }, [user?.id]);

  if (isPending || (user && profile === undefined && !error)) {
    return (
      <Shell>
        <p className="px-4 py-16 text-muted">جارٍ فتح النتائج…</p>
      </Shell>
    );
  }
  if (!user) return <Navigate to="/login" />;
  if (!profile) return <Navigate to="/join" />;

  return (
    <Shell>
      <main className="mx-auto grid max-w-6xl gap-8 px-4 py-10 lg:grid-cols-2">
        <section>
          <p className="text-sm font-semibold text-gold">ملف {profile.fullName}</p>
          <h1 className="mt-2 text-3xl font-bold">الدرجات</h1>
          {error ? <p className="mt-3 text-sm text-gold">{error}</p> : null}
          {attempts.length === 0 ? (
            <p className="mt-6 text-sm leading-relaxed text-muted">
              لا درجات بعد. ادخل امتحان صفك، والرسالة تُكتب في اللحظة نفسها.
            </p>
          ) : (
            <ul className="mt-6 grid gap-3">
              {attempts.map((attempt) => {
                const exam = findUnit(attempt.examId);
                const percent = Math.round((attempt.score / attempt.total) * 100);
                return (
                  <li key={attempt.id} className="rounded-3xl border border-line p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h2 className="font-bold">{exam?.exam.title ?? "امتحان"}</h2>
                        <p className="mt-1 text-sm text-muted">{formatWhen(attempt.createdAt)}</p>
                      </div>
                      <p className="text-end">
                        <span className="block text-2xl font-bold text-gold tabular-nums">
                          {attempt.score}/{attempt.total}
                        </span>
                        <span className="text-sm text-muted">{gradeBand(percent)}</span>
                      </p>
                    </div>
                    <div className="mt-3 h-1 rounded-full bg-line">
                      <div className="h-full rounded-full bg-gold" style={{ width: `${percent}%` }} />
                    </div>
                    <button
                      type="button"
                      className="mt-3 text-sm font-semibold text-gold"
                      onClick={() => {
                        setOpenId(attempt.id);
                        setReview(null);
                        void reviewAttempt({ data: { id: attempt.id } }).then(setReview);
                      }}
                    >
                      مراجعة الإجابات
                    </button>
                    {openId === attempt.id && review && review.ok ? (
                      <ul className="mt-3 grid gap-3">
                        {review.review.map((item, index) => (
                          <li key={item.id} className="rounded-2xl bg-surface p-3 text-sm">
                            <p className="font-semibold">
                              {index + 1}. {item.prompt}
                            </p>
                            <p className="mt-1 text-muted">إجابتك: {item.chosen ?? "بلا إجابة"}</p>
                            <p className="mt-1">الصحيحة: {item.correct}</p>
                            <p className="mt-1 text-muted">{item.explanation}</p>
                          </li>
                        ))}
                      </ul>
                    ) : null}
                  </li>
                );
              })}
            </ul>
          )}
          <Link to="/learn" className="mt-6 inline-block text-sm font-semibold text-gold">
            عودة إلى المنهج
          </Link>
        </section>
        <section>
          <h2 className="text-xl font-bold">رسائل الدرجة</h2>
          <p className="mt-2 text-sm leading-relaxed text-muted">
            كل رسالة مربوطة برقم سجّلته. إن وُصلت بوابة الإرسال تظهر حالة التسليم، وإلا تبقى الرسالة محفوظة هنا بنفس النص.
          </p>
          <div className="mt-5 grid gap-4">
            {messages.length === 0 ? <p className="text-sm text-muted">الصندوق فارغ حتى أول امتحان.</p> : null}
            {messages.map((message) => (
              <PhoneCard
                key={message.id}
                kicker={`${message.recipientRole === "parent" ? "ولي الأمر" : "الطالب"} · ${message.phone} · ${smsStatus(message.status)}`}
                body={`${message.body}\n\n${formatWhen(message.createdAt)}`}
              />
            ))}
          </div>
        </section>
      </main>
    </Shell>
  );
}
