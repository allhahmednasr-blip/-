import { createFileRoute, Link } from "@tanstack/react-router";
import { findGrade, findUnit } from "@/data/curriculum";
import { Shell, ghostBtn, goldBtn } from "@/components/shell";

export const Route = createFileRoute("/books/$bookId")({
  head: ({ params }) => ({
    meta: [{ title: `${findUnit(params.bookId)?.title ?? "كتاب"} · SCI` }],
  }),
  component: BookPage,
});

function BookPage() {
  const { bookId } = Route.useParams();
  const unit = findUnit(bookId);
  if (!unit) {
    return (
      <Shell>
        <main className="px-4 py-16">
          <h1 className="text-2xl font-bold">الكتاب غير موجود</h1>
        </main>
      </Shell>
    );
  }
  const grade = findGrade(unit.gradeId);
  return (
    <Shell>
      <main className="mx-auto max-w-3xl px-4 py-8">
        <p className="text-sm text-muted">
          <Link to="/grades/$gradeId" params={{ gradeId: unit.gradeId }} className="text-gold">
            {grade?.title}
          </Link>
        </p>
        <article className="mt-4 rounded-3xl bg-fg px-5 py-8 text-ink md:px-10">
          <p className="text-sm font-semibold text-gold-ink">
            {unit.kicker} · كتاب · {unit.book.minutes} دقائق قراءة
          </p>
          <h1 className="mt-2 text-3xl font-extrabold">{unit.title}</h1>
          <p className="mt-3 text-base leading-relaxed">{unit.summary}</p>
          <div className="mt-8 grid gap-8">
            {unit.book.sections.map((section) => (
              <section key={section.heading}>
                <h2 className="text-xl font-bold">{section.heading}</h2>
                {section.paragraphs.map((paragraph) => (
                  <p key={paragraph.slice(0, 24)} className="mt-3 leading-relaxed">
                    {paragraph}
                  </p>
                ))}
                {section.formula ? (
                  <p dir="ltr" className="mt-4 rounded-2xl bg-canvas px-4 py-3 text-center font-semibold text-fg tabular-nums">
                    {section.formula}
                  </p>
                ) : null}
                {section.example ? (
                  <p className="mt-4 rounded-2xl border border-gold-ink/30 bg-gold/15 px-4 py-3 text-sm leading-relaxed">
                    <span className="font-bold">مثال. </span>
                    {section.example}
                  </p>
                ) : null}
              </section>
            ))}
          </div>
        </article>
        <div className="mt-6 flex flex-wrap gap-3">
          <Link to="/lessons/$lessonId" params={{ lessonId: unit.id }} className={ghostBtn}>
            افتح الحصة
          </Link>
          <Link to="/exams/$examId" params={{ examId: unit.id }} className={goldBtn}>
            ادخل الامتحان
          </Link>
        </div>
      </main>
    </Shell>
  );
}
