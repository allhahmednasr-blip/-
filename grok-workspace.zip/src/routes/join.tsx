import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { GRADES, type GradeId } from "@/data/curriculum";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getProfile, saveProfile } from "@/lib/academy.functions";
import { GOVERNORATES, parseProfile } from "@/lib/student-rules";
import { Shell, fieldClass, goldBtn } from "@/components/shell";

export const Route = createFileRoute("/join")({
  head: () => ({ meta: [{ title: "اشتراك · SCI" }] }),
  component: JoinPage,
});

const paperGhost =
  "inline-flex h-11 items-center justify-center rounded-full border border-ink/20 px-5 text-sm font-semibold text-ink";

type FormState = {
  fullName: string;
  gradeId: GradeId | "";
  governorate: string;
  phone: string;
  parentPhone: string;
  email: string;
  nationalId: string;
  password: string;
};

const EMPTY: FormState = {
  fullName: "",
  gradeId: "",
  governorate: "",
  phone: "",
  parentPhone: "",
  email: "",
  nationalId: "",
  password: "",
};

function authMessage(message: string | undefined, fallback: string): string {
  const text = (message ?? "").toLowerCase();
  if (text.includes("exist") || text.includes("already")) return "هذا البريد مسجّل. ادخل من صفحة الدخول.";
  if (text.includes("password")) return "كلمة المرور ٨ أحرف على الأقل.";
  return message || fallback;
}

function JoinPage() {
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [mode, setMode] = useState<"create" | "enter">("create");
  const [form, setForm] = useState<FormState>(EMPTY);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!user) return;
    let cancel = false;
    getProfile()
      .then((profile) => {
        if (cancel) return;
        if (profile) {
          void navigate({ to: "/learn" });
          return;
        }
        setForm((current) => ({
          ...current,
          fullName: current.fullName || user.displayName || "",
          email: current.email || user.primaryEmail || "",
        }));
        setReady(true);
      })
      .catch(() => {
        if (!cancel) setReady(true);
      });
    return () => {
      cancel = true;
    };
  }, [user?.id, navigate, user]);

  function patch(partial: Partial<FormState>) {
    setForm((current) => ({ ...current, ...partial }));
  }

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setError(null);
    if (!user && mode === "enter") {
      setBusy(true);
      const result = await authClient.signIn.email({ email: form.email.trim(), password: form.password });
      setBusy(false);
      if (result.error) {
        setError(authMessage(result.error.message, "تعذر الدخول."));
        return;
      }
      window.location.assign("/learn");
      return;
    }
    if (!user && form.password.length < 8) {
      setError("كلمة المرور ٨ أحرف على الأقل.");
      return;
    }
    const parsed = parseProfile(form);
    if (!parsed.ok) {
      setError(parsed.message);
      return;
    }
    setBusy(true);
    try {
      if (!user) {
        const created = await authClient.signUp.email({
          email: parsed.value.email,
          password: form.password,
          name: parsed.value.fullName,
        });
        if (created.error) {
          setError(authMessage(created.error.message, "تعذر إنشاء الحساب."));
          setBusy(false);
          return;
        }
      }
      const saved = await saveProfile({ data: parsed.value });
      if (!saved.ok) {
        setError(saved.message);
        setBusy(false);
        return;
      }
      void navigate({ to: "/learn" });
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "تعذر حفظ الاشتراك.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Shell>
      <main className="mx-auto grid max-w-6xl gap-8 px-4 py-10 lg:grid-cols-[0.8fr_1.2fr]">
        <div>
          <p className="text-sm font-semibold text-gold">الاشتراك</p>
          <h1 className="mt-2 text-3xl font-bold">بيانات الطالب قبل أول امتحان</h1>
          <p className="mt-4 text-sm leading-relaxed text-muted">
            الاسم، الصف من أولى إعدادي إلى ثالثة ثانوي، المحافظة، موبايلك، موبايل ولي الأمر، البريد، والرقم القومي.
            الدرجة تُربط بهذه الأرقام لحظة التسليم.
          </p>
          <img src="/media/logo.jpg" alt="" className="mt-8 hidden h-20 w-auto rounded-xl lg:block" />
        </div>
        <form className="grid gap-4 rounded-3xl bg-fg p-5 text-ink md:p-7" onSubmit={(event) => void onSubmit(event)}>
          {isPending ? <p className="text-sm">جارٍ التحقق من الجلسة…</p> : null}
          {!isPending && !user ? (
            <div className="flex flex-wrap gap-2">
              <button type="button" className={mode === "create" ? goldBtn : paperGhost} onClick={() => setMode("create")}>
                حساب جديد
              </button>
              <button type="button" className={mode === "enter" ? goldBtn : paperGhost} onClick={() => setMode("enter")}>
                لدي حساب
              </button>
            </div>
          ) : null}
          {user && !ready ? <p className="text-sm">جارٍ فتح ملفك…</p> : null}
          {(user ? ready : mode === "create") && (
            <>
              <Field label="الاسم الثلاثي">
                <input className={fieldClass} value={form.fullName} onChange={(event) => patch({ fullName: event.target.value })} autoComplete="name" required />
              </Field>
              <Field label="الصف الدراسي">
                <select className={fieldClass} value={form.gradeId} onChange={(event) => patch({ gradeId: event.target.value as GradeId })} required>
                  <option value="">اختر الصف</option>
                  {GRADES.map((grade) => (
                    <option key={grade.id} value={grade.id}>
                      {grade.title}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="المحافظة">
                <select className={fieldClass} value={form.governorate} onChange={(event) => patch({ governorate: event.target.value })} required>
                  <option value="">اختر المحافظة</option>
                  {GOVERNORATES.map((name) => (
                    <option key={name} value={name}>
                      {name}
                    </option>
                  ))}
                </select>
              </Field>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="رقم هاتف الطالب">
                  <input className={fieldClass} inputMode="numeric" autoComplete="tel" maxLength={11} value={form.phone} onChange={(event) => patch({ phone: event.target.value })} required />
                </Field>
                <Field label="رقم ولي الأمر">
                  <input className={fieldClass} inputMode="numeric" autoComplete="tel" maxLength={11} value={form.parentPhone} onChange={(event) => patch({ parentPhone: event.target.value })} required />
                </Field>
              </div>
              <Field label="البريد الإلكتروني">
                <input className={fieldClass} type="email" autoComplete="email" value={form.email} onChange={(event) => patch({ email: event.target.value })} required />
              </Field>
              <Field label="الرقم القومي">
                <input className={fieldClass} inputMode="numeric" maxLength={14} value={form.nationalId} onChange={(event) => patch({ nationalId: event.target.value })} required />
              </Field>
            </>
          )}
          {!user ? (
            <Field label={mode === "create" ? "كلمة مرور للحساب" : "كلمة المرور"}>
              <input
                className={fieldClass}
                type="password"
                autoComplete={mode === "create" ? "new-password" : "current-password"}
                value={form.password}
                onChange={(event) => patch({ password: event.target.value })}
                required
              />
            </Field>
          ) : null}
          {!user && mode === "enter" ? (
            <Field label="البريد">
              <input className={fieldClass} type="email" autoComplete="email" value={form.email} onChange={(event) => patch({ email: event.target.value })} required />
            </Field>
          ) : null}
          {error ? <p className="text-sm font-semibold text-gold-ink">{error}</p> : null}
          <button className={goldBtn} type="submit" disabled={busy || isPending}>
            {busy ? "جارٍ الحفظ…" : user ? "حفظ الاشتراك" : mode === "create" ? "إنشاء الحساب والاشتراك" : "دخول"}
          </button>
          {!user && authEnabled ? (
            <div className="grid gap-2">
              {GROK_PROVIDERS.map((provider) => (
                <button
                  key={provider.providerId}
                  type="button"
                  className={paperGhost}
                  onClick={() => signIn(provider.providerId, { callbackURL: "/join" })}
                >
                  المتابعة عبر {provider.label === "Google" ? "جوجل" : "إكس"} ثم إكمال البيانات
                </button>
              ))}
            </div>
          ) : null}
          <p className="text-sm">
            <Link to="/login" className="font-semibold text-gold-ink">
              صفحة الدخول
            </Link>
          </p>
        </form>
      </main>
    </Shell>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="grid gap-1 text-sm font-semibold">
      {label}
      {children}
    </label>
  );
}
