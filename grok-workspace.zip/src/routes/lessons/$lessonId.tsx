import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { findGrade, findUnit } from "@/data/curriculum";
import { Shell, goldBtn } from "@/components/shell";

export const Route = createFileRoute("/lessons/$lessonId")({
  head: ({ params }) => ({
    meta: [{ title: `${findUnit(params.lessonId)?.title ?? "حصة"} · SCI` }],
  }),
  component: LessonPage,
});

function LessonPage() {
  const { lessonId } = Route.useParams();
  const unit = findUnit(lessonId);
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    if (!unit || !playing) return;
    const segment = unit.lesson.segments[index];
    if (!segment) return;
    const timer = window.setTimeout(() => {
      setIndex((current) => {
        if (current >= unit.lesson.segments.length - 1) {
          setPlaying(false);
          return current;
        }
        return current + 1;
      });
    }, segment.seconds * 1000);
    return () => window.clearTimeout(timer);
  }, [playing, index, unit]);

  if (!unit) {
    return (
      <Shell>
        <main className="px-4 py-16">
          <h1 className="text-2xl font-bold">الحصة غير موجودة</h1>
        </main>
      </Shell>
    );
  }

  const grade = findGrade(unit.gradeId);
  const segment = unit.lesson.segments[index] ?? unit.lesson.segments[0];
  const progress = ((index + 1) / unit.lesson.segments.length) * 100;
  if (!segment) return null;

  return (
    <Shell>
      <main className="mx-auto max-w-4xl px-4 py-8">
        <p className="text-sm text-muted">
          <Link to="/grades/$gradeId" params={{ gradeId: unit.gradeId }} className="text-gold">
            {grade?.title}
          </Link>
          <span> · حصة تفاعلية · {unit.lesson.minutes} دقائق</span>
        </p>
        <h1 className="mt-2 text-3xl font-bold">{unit.title}</h1>
        <div className="relative mt-6 overflow-hidden rounded-3xl border border-line bg-surface">
          <img
            src="/media/mentor.jpg"
            alt=""
            className="absolute end-4 bottom-4 h-28 w-20 rounded-2xl object-cover ring-1 ring-gold"
            style={{ objectPosition: "center 28%" }}
          />
          <div className="px-5 pt-6 pb-6 pe-28 md:px-8">
            <p className="text-sm text-gold">
              مقطع {index + 1} من {unit.lesson.segments.length}
            </p>
            <h2 className="mt-2 text-2xl font-bold">{segment.title}</h2>
            <p className="mt-4 max-w-2xl text-base leading-relaxed">{segment.body}</p>
            {segment.formula ? (
              <p dir="ltr" className="mt-5 inline-block rounded-2xl bg-canvas px-4 py-3 font-semibold text-gold tabular-nums">
                {segment.formula}
              </p>
            ) : null}
          </div>
          <div className="h-1 bg-line">
            <div className="h-full bg-gold" style={{ width: `${progress}%` }} />
          </div>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <button type="button" className={goldBtn} onClick={() => setPlaying((value) => !value)}>
            {playing ? "إيقاف" : "تشغيل"}
          </button>
          <button
            type="button"
            className="inline-flex h-11 items-center rounded-full border border-line px-5 text-sm font-semibold"
            onClick={() => {
              setPlaying(false);
              setIndex((current) => Math.max(0, current - 1));
            }}
            disabled={index === 0}
          >
            السابق
          </button>
          <button
            type="button"
            className="inline-flex h-11 items-center rounded-full border border-line px-5 text-sm font-semibold"
            onClick={() => {
              setPlaying(false);
              setIndex((current) => Math.min(unit.lesson.segments.length - 1, current + 1));
            }}
            disabled={index === unit.lesson.segments.length - 1}
          >
            التالي
          </button>
          <Link to="/books/$bookId" params={{ bookId: unit.id }} className="inline-flex h-11 items-center px-3 text-sm text-gold">
            اقرأ الكتاب
          </Link>
        </div>
        <ol className="mt-6 grid gap-2">
          {unit.lesson.segments.map((item, itemIndex) => (
            <li key={item.title}>
              <button
                type="button"
                onClick={() => {
                  setPlaying(false);
                  setIndex(itemIndex);
                }}
                className={`flex w-full items-center justify-between rounded-2xl border px-4 py-3 text-start text-sm ${
                  itemIndex === index ? "border-gold bg-surface" : "border-line"
                }`}
              >
                <span>{item.title}</span>
                <span className="text-muted tabular-nums">{item.seconds}ث</span>
              </button>
            </li>
          ))}
        </ol>
      </main>
    </Shell>
  );
}
