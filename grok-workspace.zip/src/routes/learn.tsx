import { useEffect, useState } from "react";
import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { findGrade, findUnit } from "@/data/curriculum";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getDesk, type AttemptSummary, type SmsMessage, type StudentProfile } from "@/lib/academy.functions";
import { maskNationalId } from "@/lib/student-rules";
import { PhoneCard, Shell, formatWhen, goldBtn, smsStatus } from "@/components/shell";

export const Route = createFileRoute("/learn")({
  head: () => ({ meta: [{ title: "منصتي · SCI" }] }),
  component: LearnPage,
});

function LearnPage() {
  const { user, isPending } = useCurrentUserState();
  const [profile, setProfile] = useState<StudentProfile | null | undefined>(undefined);
  const [attempts, setAttempts] = useState<AttemptSummary[]>([]);
  const [messages, setMessages] = useState<SmsMessage[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    let cancel = false;
    getDesk()
      .then((desk) => {
        if (cancel) return;
        setProfile(desk.profile);
        setAttempts(desk.attempts);
        setMessages(desk.messages);
      })
      .catch((cause: unknown) => {
        if (!cancel) setError(cause instanceof Error ? cause.message : "تعذر فتح المنصة");
      });
    return () => {
      cancel = true;
    };
  }, [user?.id]);

  if (isPending || (user && profile === undefined && !error)) {
    return (
      <Shell>
        <p className="px-4 py-16 text-muted">جارٍ فتح ملفك…</p>
      </Shell>
    );
  }
  if (!user) return <Navigate to="/join" />;
  if (!profile) return <Navigate to="/join" />;

  const grade = findGrade(profile.gradeId);
  const latest = messages[0];

  return (
    <Shell>
      <main className="mx-auto max-w-6xl px-4 py-10">
        <p className="text-sm font-semibold text-gold">{grade?.short}</p>
        <h1 className="mt-2 text-3xl font-bold">أهلاً {profile.fullName}</h1>
        <p className="mt-3 text-sm text-muted">
          {profile.governorate} · {profile.phone} · الرقم القومي {maskNationalId(profile.nationalId)}
        </p>
        {error ? <p className="mt-4 text-sm text-gold">{error}</p> : null}
        <div className="mt-8 grid gap-4 lg:grid-cols-[1.3fr_0.7fr]">
          <section>
            <h2 className="text-xl font-bold">وحدات صفك</h2>
            <ol className="mt-4 grid gap-3">
              {(grade?.units ?? []).map((unit) => (
                <li key={unit.id} className="rounded-3xl border border-line p-4">
                  <p className="text-sm text-gold">{unit.kicker}</p>
                  <h3 className="text-lg font-bold">{unit.title}</h3>
                  <div className="mt-3 flex flex-wrap gap-2 text-sm">
                    <Link to="/books/$bookId" params={{ bookId: unit.id }} className="inline-flex h-11 items-center rounded-full bg-surface px-4">
                      الكتاب
                    </Link>
                    <Link to="/lessons/$lessonId" params={{ lessonId: unit.id }} className="inline-flex h-11 items-center rounded-full bg-surface px-4">
                      الحصة
                    </Link>
                    <Link to="/exams/$examId" params={{ examId: unit.id }} className={goldBtn}>
                      الامتحان
                    </Link>
                  </div>
                </li>
              ))}
            </ol>
          </section>
          <aside className="grid content-start gap-4">
            <div className="rounded-3xl border border-line p-4">
              <h2 className="font-bold">آخر الدرجات</h2>
              {attempts.length === 0 ? (
                <p className="mt-2 text-sm text-muted">لم تمتحن بعد. أول تسليم يكتب الرسالة.</p>
              ) : (
                <ul className="mt-3 grid gap-2">
                  {attempts.slice(0, 4).map((attempt) => {
                    const exam = findUnit(attempt.examId);
                    const percent = Math.round((attempt.score / attempt.total) * 100);
                    return (
                      <li key={attempt.id} className="text-sm">
                        <p className="font-semibold">{exam?.exam.title ?? attempt.examId}</p>
                        <p className="text-muted tabular-nums">
                          {attempt.score}/{attempt.total} · {percent}% · {formatWhen(attempt.createdAt)}
                        </p>
                      </li>
                    );
                  })}
                </ul>
              )}
              <Link to="/results" className="mt-4 inline-block text-sm font-semibold text-gold">
                كل النتائج والرسائل
              </Link>
            </div>
            {latest ? (
              <PhoneCard kicker={`${smsStatus(latest.status)} · ${latest.phone}`} body={latest.body} />
            ) : null}
          </aside>
        </div>
      </main>
    </Shell>
  );
}
