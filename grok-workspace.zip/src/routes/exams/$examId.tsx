import { useEffect, useRef, useState } from "react";
import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { findGrade, findUnit } from "@/data/curriculum";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getExamPaper, getProfile, submitExam, type SmsMessage } from "@/lib/academy.functions";
import { PhoneCard, Shell, goldBtn, smsStatus } from "@/components/shell";

export const Route = createFileRoute("/exams/$examId")({
  head: ({ params }) => ({
    meta: [{ title: `${findUnit(params.examId)?.exam.title ?? "امتحان"} · SCI` }],
  }),
  component: ExamPage,
});

type Paper = {
  title: string;
  minutes: number;
  questions: { id: string; prompt: string; choices: string[] }[];
};

type Result = {
  score: number;
  total: number;
  percent: number;
  gradeLabel: string;
  review: {
    id: string;
    prompt: string;
    chosen: string | null;
    correct: string;
    explanation: string;
    right: boolean;
  }[];
  messages: SmsMessage[];
};

function clock(total: number): string {
  const minutes = Math.floor(total / 60);
  const seconds = total % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

function ExamPage() {
  const { examId } = Route.useParams();
  const unit = findUnit(examId);
  const { user, isPending } = useCurrentUserState();
  const [gate, setGate] = useState<"loading" | "guest" | "join" | "ready" | "error">("loading");
  const [paper, setPaper] = useState<Paper | null>(null);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [left, setLeft] = useState<number | null>(null);
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<Result | null>(null);
  const lock = useRef(false);

  useEffect(() => {
    if (isPending) return;
    if (!user) {
      setGate("guest");
      return;
    }
    let cancel = false;
    getProfile()
      .then(async (profile) => {
        if (cancel) return;
        if (!profile) {
          setGate("join");
          return;
        }
        const loaded = await getExamPaper({ data: { examId } });
        if (cancel) return;
        if (!loaded.ok) {
          setError(loaded.message);
          setGate("error");
          return;
        }
        setPaper(loaded.paper);
        setLeft(loaded.paper.minutes * 60);
        setGate("ready");
      })
      .catch((cause: unknown) => {
        if (cancel) return;
        setError(cause instanceof Error ? cause.message : "تعذر فتح الامتحان");
        setGate("error");
      });
    return () => {
      cancel = true;
    };
  }, [user?.id, isPending, examId]);

  async function finish() {
    if (!paper || lock.current || result) return;
    lock.current = true;
    setBusy(true);
    setError(null);
    try {
      const response = await submitExam({ data: { examId, answers } });
      if (!response.ok) {
        lock.current = false;
        setError(response.message);
        setBusy(false);
        return;
      }
      setResult(response);
      setConfirming(false);
    } catch (cause) {
      lock.current = false;
      setError(cause instanceof Error ? cause.message : "تعذر التسليم");
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    if (left == null || result || gate !== "ready") return;
    if (left <= 0) {
      void finish();
      return;
    }
    const timer = window.setTimeout(() => setLeft((value) => (value == null ? value : value - 1)), 1000);
    return () => window.clearTimeout(timer);
  }, [left, result, gate]);

  if (!unit) {
    return (
      <Shell>
        <main className="px-4 py-16">
          <h1 className="text-2xl font-bold">الامتحان غير موجود</h1>
        </main>
      </Shell>
    );
  }

  const grade = findGrade(unit.gradeId);
  const answered = paper ? paper.questions.filter((question) => answers[question.id]).length : 0;

  return (
    <Shell>
      <main className="mx-auto max-w-3xl px-4 py-8 pb-28">
        <p className="text-sm text-muted">
          <Link to="/grades/$gradeId" params={{ gradeId: unit.gradeId }} className="text-gold">
            {grade?.title}
          </Link>
        </p>
        <div className="mt-2 flex items-start justify-between gap-4">
          <h1 className="text-3xl font-bold">{unit.exam.title}</h1>
          {left != null && !result ? <p className="text-2xl font-bold text-gold tabular-nums">{clock(left)}</p> : null}
        </div>
        <p className="mt-3 text-sm leading-relaxed text-muted">
          {unit.exam.count} أسئلة · {unit.exam.minutes} دقائق. التصحيح على الخادم، ثم تُكتب رسالة الدرجة لرقمك ورقم ولي الأمر.
        </p>

        {isPending || gate === "loading" ? <p className="mt-8 text-muted">جارٍ تجهيز ورقة الأسئلة…</p> : null}
        {gate === "guest" ? <Navigate to="/login" /> : null}
        {gate === "join" ? (
          <div className="mt-8 rounded-3xl border border-line p-5">
            <p>الامتحان يُفتح بعد ما يكتمل الاشتراك.</p>
            <Link to="/join" className={`${goldBtn} mt-4`}>
              أكمل الاشتراك
            </Link>
          </div>
        ) : null}
        {error ? <p className="mt-4 text-sm font-semibold text-gold">{error}</p> : null}

        {paper && !result ? (
          <ol className="mt-8 grid gap-6">
            {paper.questions.map((question, index) => (
              <li key={question.id} className="rounded-3xl border border-line p-4">
                <p className="font-bold">
                  {index + 1}. {question.prompt}
                </p>
                <div className="mt-3 grid gap-2">
                  {question.choices.map((choice) => (
                    <label key={choice} className="flex items-start gap-3 rounded-2xl border border-line px-3 py-3 has-[:checked]:border-gold has-[:checked]:bg-surface">
                      <input
                        type="radio"
                        name={question.id}
                        className="mt-1"
                        checked={answers[question.id] === choice}
                        onChange={() => setAnswers((current) => ({ ...current, [question.id]: choice }))}
                      />
                      <span className="text-sm leading-relaxed">{choice}</span>
                    </label>
                  ))}
                </div>
              </li>
            ))}
          </ol>
        ) : null}

        {result ? (
          <section className="mt-8 grid gap-4">
            <div className="rounded-3xl bg-fg p-5 text-ink">
              <p className="text-sm font-semibold text-gold-ink">نتيجتك</p>
              <p className="mt-2 text-4xl font-extrabold tabular-nums">
                {result.score}/{result.total}
              </p>
              <p className="mt-1">
                {result.percent}% · {result.gradeLabel}
              </p>
            </div>
            <div className="grid gap-3">
              {result.messages.map((message) => (
                <PhoneCard
                  key={message.id}
                  kicker={`${message.recipientRole === "parent" ? "إلى ولي الأمر" : "إلى الطالب"} · ${message.phone} · ${smsStatus(message.status)}`}
                  body={message.body}
                />
              ))}
            </div>
            <ol className="grid gap-3">
              {result.review.map((item, index) => (
                <li key={item.id} className="rounded-3xl border border-line p-4 text-sm">
                  <p className="font-bold">
                    {index + 1}. {item.prompt}
                  </p>
                  <p className="mt-2 text-muted">إجابتك: {item.chosen ?? "بلا إجابة"}</p>
                  <p className="mt-1">الصحيحة: {item.correct}</p>
                  <p className="mt-2 leading-relaxed text-muted">{item.explanation}</p>
                </li>
              ))}
            </ol>
            <Link to="/results" className={goldBtn}>
              صندوق الدرجات والرسائل
            </Link>
          </section>
        ) : null}
      </main>
      {paper && !result ? (
        <div className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-canvas/95 px-4 py-3 backdrop-blur">
          <div className="mx-auto flex max-w-3xl items-center justify-between gap-3">
            <p className="text-sm text-muted tabular-nums">
              أجبت {answered} من {paper.questions.length}
            </p>
            {confirming ? (
              <div className="flex gap-2">
                <button type="button" className="h-11 rounded-full border border-line px-4 text-sm" onClick={() => setConfirming(false)}>
                  رجوع
                </button>
                <button type="button" className={goldBtn} disabled={busy} onClick={() => void finish()}>
                  {busy ? "جارٍ التصحيح…" : "تأكيد التسليم"}
                </button>
              </div>
            ) : (
              <button type="button" className={goldBtn} onClick={() => setConfirming(true)}>
                تسليم الامتحان
              </button>
            )}
          </div>
        </div>
      ) : null}
    </Shell>
  );
}
