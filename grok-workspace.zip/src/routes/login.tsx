import { useState } from "react";
import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Shell, fieldClass, goldBtn, ghostBtn } from "@/components/shell";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "دخول · SCI" }] }),
  component: LoginPage,
});

function authMessage(message: string | undefined): string {
  const text = (message ?? "").toLowerCase();
  if (text.includes("invalid") && text.includes("password")) return "البريد أو كلمة المرور غير صحيحة.";
  if (text.includes("password")) return "تحقق من كلمة المرور.";
  if (text.includes("user") || text.includes("found")) return "لا يوجد حساب بهذا البريد. اشترك أولاً.";
  return message || "تعذر الدخول.";
}

function LoginPage() {
  const { user, isPending } = useCurrentUserState();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (isPending) {
    return (
      <Shell>
        <p className="px-4 py-16 text-muted">جارٍ التحقق من الجلسة…</p>
      </Shell>
    );
  }
  if (user) return <Navigate to="/learn" />;

  return (
    <Shell>
      <main className="mx-auto grid max-w-md gap-6 px-4 py-12">
        <div>
          <p className="text-sm font-semibold text-gold">حساب موجود</p>
          <h1 className="mt-2 text-3xl font-bold">ادخل إلى منصتك</h1>
        </div>
        <form
          className="grid gap-3 rounded-3xl bg-fg p-5 text-ink"
          onSubmit={(event) => {
            event.preventDefault();
            setBusy(true);
            setError(null);
            void authClient.signIn
              .email({ email: email.trim(), password })
              .then((result) => {
                if (result.error) {
                  setError(authMessage(result.error.message));
                  setBusy(false);
                  return;
                }
                window.location.assign("/learn");
              })
              .catch(() => {
                setError("تعذر الدخول.");
                setBusy(false);
              });
          }}
        >
          <label className="grid gap-1 text-sm font-semibold">
            البريد
            <input
              className={fieldClass}
              type="email"
              autoComplete="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              required
            />
          </label>
          <label className="grid gap-1 text-sm font-semibold">
            كلمة المرور
            <input
              className={fieldClass}
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              required
            />
          </label>
          {error ? <p className="text-sm font-semibold text-gold-ink">{error}</p> : null}
          <button className={goldBtn} type="submit" disabled={busy}>
            {busy ? "جارٍ الدخول…" : "دخول"}
          </button>
        </form>
        {authEnabled ? (
          <div className="grid gap-2">
            {GROK_PROVIDERS.map((provider) => (
              <button
                key={provider.providerId}
                type="button"
                className={ghostBtn}
                onClick={() => signIn(provider.providerId, { callbackURL: "/learn" })}
              >
                المتابعة عبر {provider.label === "Google" ? "جوجل" : "إكس"}
              </button>
            ))}
          </div>
        ) : null}
        <p className="text-sm text-muted">
          أول مرة؟{" "}
          <Link to="/join" className="font-semibold text-gold">
            اشترك من هنا
          </Link>
        </p>
      </main>
    </Shell>
  );
}
