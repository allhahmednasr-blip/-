import { createFileRoute, Link } from "@tanstack/react-router";
import { GRADES } from "@/data/curriculum";
import { Shell } from "@/components/shell";

export const Route = createFileRoute("/grades/")({
  head: () => ({ meta: [{ title: "الصفوف · SCI" }] }),
  component: GradesPage,
});

function GradesPage() {
  return (
    <Shell>
      <main className="mx-auto max-w-6xl px-4 py-10">
        <p className="text-sm font-semibold text-gold">المنهج</p>
        <h1 className="mt-2 text-3xl font-bold">من أولى إعدادي إلى تالتة ثانوي</h1>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted">
          كل صف فيه كتاب وحصة وامتحان. الامتحان يُفتح بعد الاشتراك، والكتاب والحصة متاحان للقراءة قبل ذلك.
        </p>
        <div className="mt-8 grid gap-4 md:grid-cols-2">
          {GRADES.map((grade) => (
            <Link
              key={grade.id}
              to="/grades/$gradeId"
              params={{ gradeId: grade.id }}
              className="rounded-3xl border border-line bg-surface p-5 transition hover:border-gold"
            >
              <p className="text-sm text-gold">{grade.stage}</p>
              <h2 className="mt-1 text-2xl font-bold">{grade.title}</h2>
              <p className="mt-2 text-sm leading-relaxed text-muted">{grade.promise}</p>
              <p className="mt-4 text-sm">{grade.units.length} وحدات</p>
            </Link>
          ))}
        </div>
      </main>
    </Shell>
  );
}
