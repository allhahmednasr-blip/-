import { createFileRoute, Link } from "@tanstack/react-router";
import { findGrade } from "@/data/curriculum";
import { Shell } from "@/components/shell";

export const Route = createFileRoute("/grades/$gradeId")({
  head: ({ params }) => ({
    meta: [{ title: `${findGrade(params.gradeId)?.title ?? "الصف"} · SCI` }],
  }),
  component: GradePage,
});

function GradePage() {
  const { gradeId } = Route.useParams();
  const grade = findGrade(gradeId);
  if (!grade) {
    return (
      <Shell>
        <main className="mx-auto max-w-3xl px-4 py-16">
          <h1 className="text-2xl font-bold">هذا الصف غير موجود</h1>
          <Link to="/grades" className="mt-4 inline-block text-gold">
            عودة إلى الصفوف
          </Link>
        </main>
      </Shell>
    );
  }
  return (
    <Shell>
      <main className="mx-auto max-w-6xl px-4 py-10">
        <p className="text-sm font-semibold text-gold">{grade.stage}</p>
        <h1 className="mt-2 text-3xl font-bold">{grade.title}</h1>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted">{grade.promise}</p>
        <ol className="mt-8 grid gap-4">
          {grade.units.map((item) => (
            <li key={item.id} className="rounded-3xl border border-line p-5">
              <p className="text-sm text-gold">{item.kicker}</p>
              <h2 className="mt-1 text-2xl font-bold">{item.title}</h2>
              <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted">{item.summary}</p>
              <div className="mt-4 flex flex-wrap gap-2 text-sm">
                <Link
                  to="/books/$bookId"
                  params={{ bookId: item.id }}
                  className="inline-flex h-11 items-center rounded-full bg-surface px-4 font-semibold"
                >
                  الكتاب
                </Link>
                <Link
                  to="/lessons/$lessonId"
                  params={{ lessonId: item.id }}
                  className="inline-flex h-11 items-center rounded-full bg-surface px-4 font-semibold"
                >
                  الحصة
                </Link>
                <Link
                  to="/exams/$examId"
                  params={{ examId: item.id }}
                  className="inline-flex h-11 items-center rounded-full bg-gold px-4 font-bold text-ink"
                >
                  الامتحان
                </Link>
              </div>
            </li>
          ))}
        </ol>
      </main>
    </Shell>
  );
}
