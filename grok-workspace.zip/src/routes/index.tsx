import { createFileRoute, Link } from "@tanstack/react-router";
import { GRADES } from "@/data/curriculum";
import { PHILOSOPHY, PILLARS, PROMISES, TAGLINE } from "@/data/copy";
import { PhoneCard, Shell, goldBtn, ghostBtn } from "@/components/shell";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/")({ component: Home });

function EnterLinks() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) return <span className="inline-block h-11 w-40 rounded-full bg-surface" />;
  if (user) {
    return (
      <Link to="/learn" className={goldBtn}>
        ادخل منصتك
      </Link>
    );
  }
  return (
    <Link to="/join" className={goldBtn}>
      اشترك الآن
    </Link>
  );
}

function Home() {
  return (
    <Shell>
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/media/mentor.jpg"
            alt=""
            className="h-full w-full object-cover"
            style={{ objectPosition: "center 16%" }}
          />
          <div className="hero-veil absolute inset-0" />
          <div className="dot-grid absolute inset-0 opacity-40" />
        </div>
        <div className="relative mx-auto flex min-h-[88svh] max-w-6xl flex-col justify-end px-4 pt-8 pb-12">
          <div className="max-w-2xl rounded-3xl bg-canvas/80 p-5 ring-1 ring-line md:p-8">
            <img src="/media/logo.jpg" alt="شعار قناة SCI TV" className="h-16 w-auto max-w-full rounded-xl" />
            <p className="mt-5 text-sm font-semibold text-gold">معلم الكيمياء · قناة SCI TV</p>
            <h1 className="mt-2 text-4xl font-extrabold leading-tight md:text-6xl">{TAGLINE}</h1>
            <p className="mt-4 max-w-xl text-base leading-relaxed text-muted md:text-lg">
              منصة كيمياء من الصف الأول الإعدادي إلى الصف الثالث الثانوي. كتاب تقرأه، حصة تسير فيها خطوة بخطوة،
              وامتحان تُكتب درجته رسالة على موبايلك وموبايل ولي أمرك.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <EnterLinks />
              <Link to="/grades" className={ghostBtn}>
                تصفح الصفوف
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-4 py-16 md:py-24">
        <p className="text-sm font-semibold text-gold">لماذا بُنيت المنصة</p>
        <blockquote className="mt-5 font-serif text-xl leading-loose text-fg md:text-2xl">{PHILOSOPHY}</blockquote>
      </section>

      <section className="border-y border-line">
        <div className="mx-auto grid max-w-6xl gap-px bg-line md:grid-cols-3">
          {PILLARS.map((pillar) => (
            <article key={pillar.title} className="bg-canvas px-5 py-8">
              <p className="font-serif text-3xl text-gold">{pillar.n}</p>
              <h2 className="mt-3 text-2xl font-bold">{pillar.title}</h2>
              <p className="mt-3 text-sm leading-relaxed text-muted">{pillar.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section id="grades" className="mx-auto max-w-6xl px-4 py-16">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="text-sm font-semibold text-gold">المنهج</p>
            <h2 className="mt-2 text-3xl font-bold">ستة صفوف، خط واحد</h2>
          </div>
          <Link to="/grades" className="text-sm font-semibold text-gold">
            كل الوحدات
          </Link>
        </div>
        <ol className="mt-8 divide-y divide-line border-y border-line">
          {GRADES.map((grade, index) => (
            <li key={grade.id}>
              <Link to="/grades/$gradeId" params={{ gradeId: grade.id }} className="flex items-start gap-4 py-5">
                <span className="w-10 font-serif text-2xl text-gold tabular-nums">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-lg font-bold">{grade.title}</span>
                  <span className="mt-1 block text-sm leading-relaxed text-muted">{grade.promise}</span>
                </span>
                <span className="hidden text-sm text-muted sm:block">{grade.units.length} وحدات</span>
              </Link>
            </li>
          ))}
        </ol>
      </section>

      <section className="border-t border-line bg-surface/40">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 md:grid-cols-2">
          <div>
            <p className="text-sm font-semibold text-gold">رسالة الدرجة</p>
            <h2 className="mt-2 text-3xl font-bold">أول ما تسلّم، الرسالة تتكتب</h2>
            <p className="mt-4 text-sm leading-relaxed text-muted md:text-base">
              التصحيح يتم على الخادم، لا في المتصفح. بعدها تُنشأ رسالة للطالب وأخرى لولي الأمر فيها الاسم والامتحان
              والدرجة والتقدير. تجد النص فوراً في صندوق النتائج، مربوطاً بالرقمين اللذين سجّلتهما عند الاشتراك.
            </p>
            <ul className="mt-6 grid gap-3 sm:grid-cols-2">
              {PROMISES.map((item) => (
                <li key={item.title} className="rounded-2xl border border-line px-4 py-3">
                  <p className="font-bold">{item.title}</p>
                  <p className="mt-1 text-sm leading-relaxed text-muted">{item.text}</p>
                </li>
              ))}
            </ul>
          </div>
          <PhoneCard
            kicker="نموذج الرسالة · الآن"
            body={"SCI | أكاديمية الكيمياء\nالطالب: ———\nالامتحان: الاتزان الكيميائي\nالدرجة: 4 من 5 (80%)\nالتقدير: جيد جداً\nراجع تفسير الإجابات داخل المنصة."}
          />
        </div>
      </section>
    </Shell>
  );
}
