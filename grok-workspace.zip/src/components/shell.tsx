import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const goldBtn =
  "inline-flex h-11 items-center justify-center rounded-full bg-gold px-5 text-sm font-bold text-ink transition hover:opacity-90";
export const ghostBtn =
  "inline-flex h-11 items-center justify-center rounded-full border border-line px-5 text-sm font-semibold text-fg transition hover:bg-surface";
export const fieldClass =
  "h-12 w-full rounded-2xl border border-ink/15 bg-fg px-3 text-ink outline-none focus:border-gold-ink";

export function SiteHeader() {
  const { user, isPending } = useCurrentUserState();
  return (
    <header className="sticky top-0 z-30 border-b border-line bg-canvas/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
        <Link to="/" className="flex min-w-0 items-center gap-3">
          <img src="/media/logo.jpg" alt="شعار SCI TV" className="h-11 w-auto rounded-lg" />
          <span className="hidden truncate text-sm font-bold sm:block">أكاديمية الكيمياء</span>
        </Link>
        <nav className="ms-auto hidden items-center gap-5 text-sm text-muted md:flex">
          <Link to="/grades" className="hover:text-fg">
            الصفوف
          </Link>
          <Link to="/learn" className="hover:text-fg">
            منصتي
          </Link>
          <Link to="/results" className="hover:text-fg">
            النتائج والرسائل
          </Link>
        </nav>
        <div className="ms-auto max-w-[42vw] overflow-hidden md:ms-0 md:max-w-none">
          {isPending ? (
            <span className="inline-block h-10 w-24 rounded-full bg-surface" />
          ) : user ? (
            <UserButton />
          ) : (
            <Link to="/join" className={goldBtn}>
              اشترك
            </Link>
          )}
        </div>
      </div>
      <nav className="mx-auto flex max-w-6xl gap-4 overflow-x-auto px-4 pb-3 text-sm text-muted md:hidden">
        <Link to="/grades" className="shrink-0 hover:text-fg">
          الصفوف
        </Link>
        <Link to="/learn" className="shrink-0 hover:text-fg">
          منصتي
        </Link>
        <Link to="/results" className="shrink-0 hover:text-fg">
          النتائج
        </Link>
        <Link to="/join" className="shrink-0 hover:text-fg">
          الاشتراك
        </Link>
      </nav>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="border-t border-line">
      <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-8 text-sm text-muted sm:flex-row sm:items-center sm:justify-between">
        <p>SCI TV · أكاديمية الكيمياء</p>
        <p>معاً نبني جيلاً أكثر معرفة</p>
      </div>
    </footer>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <div className="flex-1">{children}</div>
      <SiteFooter />
    </div>
  );
}

export function PhoneCard({ kicker, body }: { kicker: string; body: string }) {
  return (
    <div className="w-full max-w-sm rounded-3xl border border-line bg-canvas p-3">
      <div className="rounded-3xl bg-surface px-4 py-5">
        <div className="mx-auto mb-4 h-1 w-14 rounded-full bg-line" />
        <p className="text-xs font-semibold text-gold">{kicker}</p>
        <p className="mt-3 text-sm leading-relaxed break-words whitespace-pre-line">{body}</p>
      </div>
    </div>
  );
}

export function formatWhen(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("ar-EG", { dateStyle: "medium", timeStyle: "short" }).format(date);
}

export function smsStatus(status: string): string {
  if (status === "sent") return "سُلّمت إلى بوابة الرسائل";
  return "مسجّلة الآن على هذا الرقم داخل الأكاديمية";
}
