import { t as GRADES } from "./db-BJvgvhpp.mjs";
import { C as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Shell } from "./shell-C7P0fcYy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/grades-EQDspqn6.js
var import_jsx_runtime = require_jsx_runtime();
function GradesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold text-gold",
				children: "المنهج"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-3xl font-bold",
				children: "من أولى إعدادي إلى تالتة ثانوي"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-2xl text-sm leading-relaxed text-muted",
				children: "كل صف فيه كتاب وحصة وامتحان. الامتحان يُفتح بعد الاشتراك، والكتاب والحصة متاحان للقراءة قبل ذلك."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-4 md:grid-cols-2",
				children: GRADES.map((grade) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/grades/$gradeId",
					params: { gradeId: grade.id },
					className: "rounded-3xl border border-line bg-surface p-5 transition hover:border-gold",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-gold",
							children: grade.stage
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 text-2xl font-bold",
							children: grade.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: grade.promise
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 text-sm",
							children: [grade.units.length, " وحدات"]
						})
					]
				}, grade.id))
			})
		]
	}) });
}
//#endregion
export { GradesPage as component };
