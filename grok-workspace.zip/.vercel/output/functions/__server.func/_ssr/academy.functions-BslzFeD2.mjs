import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-DpANBPok.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/academy.functions-BslzFeD2.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getProfile = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("9c65100c1a906b4019b4feb8c5d3dc12df6374b1169ea1b75fe38fda3bea36b3"));
var getDesk = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("1f8f5b90bb94d539386e04765b7d0d083092e4b913facba16efcc3fa0527235b"));
var saveProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("452e3ca3484ee79cd17be26f9c2a6f1517a7d482dc41a50a6cb439b7d89b5250"));
var getExamPaper = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	return { examId: typeof input === "object" && input && "examId" in input ? String(input.examId) : "" };
}).handler(createSsrRpc("380d6cce1ac70ee1d6a337fbbfebf20c4f58a6d80fdeeddf2ebcd33370094c2f"));
var submitExam = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input || typeof input !== "object") return {
		examId: "",
		answers: {}
	};
	const raw = input;
	const answers = {};
	if (raw.answers && typeof raw.answers === "object") {
		for (const [key, value] of Object.entries(raw.answers)) if (typeof value === "string" && value.length < 400) answers[key] = value;
	}
	return {
		examId: String(raw.examId ?? ""),
		answers
	};
}).handler(createSsrRpc("583620a330d3d57bde93c05c81aa6025586569b9259cb46b218982493410fbff"));
var reviewAttempt = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const id = Number(typeof input === "object" && input && "id" in input ? input.id : input);
	if (!Number.isInteger(id) || id <= 0) throw new Error("محاولة غير صالحة");
	return id;
}).handler(createSsrRpc("d713cc8b64247b3626891b634ea520705363eb7d34d8b9e3e49c9fd3edfbfd6a"));
//#endregion
export { saveProfile as a, reviewAttempt as i, getExamPaper as n, submitExam as o, getProfile as r, getDesk as t };
