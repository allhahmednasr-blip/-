import { o as __toESM } from "../_runtime.mjs";
import { a as findUnit } from "./db-BJvgvhpp.mjs";
import { C as require_jsx_runtime, X as require_react, b as Navigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as useCurrentUserState, i as formatWhen, n as Shell, s as smsStatus, t as PhoneCard } from "./shell-C7P0fcYy.mjs";
import { i as reviewAttempt, t as getDesk } from "./academy.functions-BslzFeD2.mjs";
import { n as gradeBand } from "./student-rules-rhA8dadI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/results-3_sCNlCN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ResultsPage() {
	const { user, isPending } = useCurrentUserState();
	const [profile, setProfile] = (0, import_react.useState)(void 0);
	const [attempts, setAttempts] = (0, import_react.useState)([]);
	const [messages, setMessages] = (0, import_react.useState)([]);
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const [review, setReview] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		let cancel = false;
		getDesk().then((desk) => {
			if (cancel) return;
			setProfile(desk.profile);
			setAttempts(desk.attempts);
			setMessages(desk.messages);
		}).catch((cause) => {
			if (!cancel) setError(cause instanceof Error ? cause.message : "تعذر التحميل");
		});
		return () => {
			cancel = true;
		};
	}, [user?.id]);
	if (isPending || user && profile === void 0 && !error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-4 py-16 text-muted",
		children: "جارٍ فتح النتائج…"
	}) });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/login" });
	if (!profile) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/join" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto grid max-w-6xl gap-8 px-4 py-10 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm font-semibold text-gold",
				children: ["ملف ", profile.fullName]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-3xl font-bold",
				children: "الدرجات"
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-gold",
				children: error
			}) : null,
			attempts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm leading-relaxed text-muted",
				children: "لا درجات بعد. ادخل امتحان صفك، والرسالة تُكتب في اللحظة نفسها."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 grid gap-3",
				children: attempts.map((attempt) => {
					const exam = findUnit(attempt.examId);
					const percent = Math.round(attempt.score / attempt.total * 100);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-3xl border border-line p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-bold",
									children: exam?.exam.title ?? "امتحان"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: formatWhen(attempt.createdAt)
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-end",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block text-2xl font-bold text-gold tabular-nums",
										children: [
											attempt.score,
											"/",
											attempt.total
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm text-muted",
										children: gradeBand(percent)
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 h-1 rounded-full bg-line",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-gold",
									style: { width: `${percent}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "mt-3 text-sm font-semibold text-gold",
								onClick: () => {
									setOpenId(attempt.id);
									setReview(null);
									reviewAttempt({ data: { id: attempt.id } }).then(setReview);
								},
								children: "مراجعة الإجابات"
							}),
							openId === attempt.id && review && review.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-3 grid gap-3",
								children: review.review.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "rounded-2xl bg-surface p-3 text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "font-semibold",
											children: [
												index + 1,
												". ",
												item.prompt
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-1 text-muted",
											children: ["إجابتك: ", item.chosen ?? "بلا إجابة"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-1",
											children: ["الصحيحة: ", item.correct]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-muted",
											children: item.explanation
										})
									]
								}, item.id))
							}) : null
						]
					}, attempt.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/learn",
				className: "mt-6 inline-block text-sm font-semibold text-gold",
				children: "عودة إلى المنهج"
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-bold",
				children: "رسائل الدرجة"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-muted",
				children: "كل رسالة مربوطة برقم سجّلته. إن وُصلت بوابة الإرسال تظهر حالة التسليم، وإلا تبقى الرسالة محفوظة هنا بنفس النص."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 grid gap-4",
				children: [messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "الصندوق فارغ حتى أول امتحان."
				}) : null, messages.map((message) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneCard, {
					kicker: `${message.recipientRole === "parent" ? "ولي الأمر" : "الطالب"} · ${message.phone} · ${smsStatus(message.status)}`,
					body: `${message.body}\n\n${formatWhen(message.createdAt)}`
				}, message.id))]
			})
		] })]
	}) });
}
//#endregion
export { ResultsPage as component };
