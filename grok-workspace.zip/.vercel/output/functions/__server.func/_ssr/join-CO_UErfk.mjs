import { o as __toESM } from "../_runtime.mjs";
import { t as GRADES } from "./db-BJvgvhpp.mjs";
import { t as GROK_PROVIDERS } from "./server-CYvelK-S.mjs";
import { C as require_jsx_runtime, X as require_react, x as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as signIn, t as authClient } from "./client-IWHfIGH2.mjs";
import { c as useCurrentUserState, n as Shell, o as goldBtn, r as fieldClass } from "./shell-C7P0fcYy.mjs";
import { a as saveProfile, r as getProfile } from "./academy.functions-BslzFeD2.mjs";
import { i as parseProfile, t as GOVERNORATES } from "./student-rules-rhA8dadI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/join-CO_UErfk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var paperGhost = "inline-flex h-11 items-center justify-center rounded-full border border-ink/20 px-5 text-sm font-semibold text-ink";
var EMPTY = {
	fullName: "",
	gradeId: "",
	governorate: "",
	phone: "",
	parentPhone: "",
	email: "",
	nationalId: "",
	password: ""
};
function authMessage(message, fallback) {
	const text = (message ?? "").toLowerCase();
	if (text.includes("exist") || text.includes("already")) return "هذا البريد مسجّل. ادخل من صفحة الدخول.";
	if (text.includes("password")) return "كلمة المرور ٨ أحرف على الأقل.";
	return message || fallback;
}
function JoinPage() {
	const navigate = useNavigate();
	const { user, isPending } = useCurrentUserState();
	const [mode, setMode] = (0, import_react.useState)("create");
	const [form, setForm] = (0, import_react.useState)(EMPTY);
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		let cancel = false;
		getProfile().then((profile) => {
			if (cancel) return;
			if (profile) {
				navigate({ to: "/learn" });
				return;
			}
			setForm((current) => ({
				...current,
				fullName: current.fullName || user.displayName || "",
				email: current.email || user.primaryEmail || ""
			}));
			setReady(true);
		}).catch(() => {
			if (!cancel) setReady(true);
		});
		return () => {
			cancel = true;
		};
	}, [
		user?.id,
		navigate,
		user
	]);
	function patch(partial) {
		setForm((current) => ({
			...current,
			...partial
		}));
	}
	async function onSubmit(event) {
		event.preventDefault();
		setError(null);
		if (!user && mode === "enter") {
			setBusy(true);
			const result = await authClient.signIn.email({
				email: form.email.trim(),
				password: form.password
			});
			setBusy(false);
			if (result.error) {
				setError(authMessage(result.error.message, "تعذر الدخول."));
				return;
			}
			window.location.assign("/learn");
			return;
		}
		if (!user && form.password.length < 8) {
			setError("كلمة المرور ٨ أحرف على الأقل.");
			return;
		}
		const parsed = parseProfile(form);
		if (!parsed.ok) {
			setError(parsed.message);
			return;
		}
		setBusy(true);
		try {
			if (!user) {
				const created = await authClient.signUp.email({
					email: parsed.value.email,
					password: form.password,
					name: parsed.value.fullName
				});
				if (created.error) {
					setError(authMessage(created.error.message, "تعذر إنشاء الحساب."));
					setBusy(false);
					return;
				}
			}
			const saved = await saveProfile({ data: parsed.value });
			if (!saved.ok) {
				setError(saved.message);
				setBusy(false);
				return;
			}
			navigate({ to: "/learn" });
		} catch (cause) {
			setError(cause instanceof Error ? cause.message : "تعذر حفظ الاشتراك.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto grid max-w-6xl gap-8 px-4 py-10 lg:grid-cols-[0.8fr_1.2fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold text-gold",
				children: "الاشتراك"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-3xl font-bold",
				children: "بيانات الطالب قبل أول امتحان"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm leading-relaxed text-muted",
				children: "الاسم، الصف من أولى إعدادي إلى ثالثة ثانوي، المحافظة، موبايلك، موبايل ولي الأمر، البريد، والرقم القومي. الدرجة تُربط بهذه الأرقام لحظة التسليم."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/media/logo.jpg",
				alt: "",
				className: "mt-8 hidden h-20 w-auto rounded-xl lg:block"
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-4 rounded-3xl bg-fg p-5 text-ink md:p-7",
			onSubmit: (event) => void onSubmit(event),
			children: [
				isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "جارٍ التحقق من الجلسة…"
				}) : null,
				!isPending && !user ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: mode === "create" ? goldBtn : paperGhost,
						onClick: () => setMode("create"),
						children: "حساب جديد"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: mode === "enter" ? goldBtn : paperGhost,
						onClick: () => setMode("enter"),
						children: "لدي حساب"
					})]
				}) : null,
				user && !ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "جارٍ فتح ملفك…"
				}) : null,
				(user ? ready : mode === "create") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الاسم الثلاثي",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "h-12 w-full rounded-2xl border border-ink/15 bg-fg px-3 text-ink outline-none focus:border-gold-ink",
							value: form.fullName,
							onChange: (event) => patch({ fullName: event.target.value }),
							autoComplete: "name",
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الصف الدراسي",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "h-12 w-full rounded-2xl border border-ink/15 bg-fg px-3 text-ink outline-none focus:border-gold-ink",
							value: form.gradeId,
							onChange: (event) => patch({ gradeId: event.target.value }),
							required: true,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "اختر الصف"
							}), GRADES.map((grade) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: grade.id,
								children: grade.title
							}, grade.id))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "المحافظة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "h-12 w-full rounded-2xl border border-ink/15 bg-fg px-3 text-ink outline-none focus:border-gold-ink",
							value: form.governorate,
							onChange: (event) => patch({ governorate: event.target.value }),
							required: true,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "اختر المحافظة"
							}), GOVERNORATES.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: name,
								children: name
							}, name))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "رقم هاتف الطالب",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "h-12 w-full rounded-2xl border border-ink/15 bg-fg px-3 text-ink outline-none focus:border-gold-ink",
								inputMode: "numeric",
								autoComplete: "tel",
								maxLength: 11,
								value: form.phone,
								onChange: (event) => patch({ phone: event.target.value }),
								required: true
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "رقم ولي الأمر",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "h-12 w-full rounded-2xl border border-ink/15 bg-fg px-3 text-ink outline-none focus:border-gold-ink",
								inputMode: "numeric",
								autoComplete: "tel",
								maxLength: 11,
								value: form.parentPhone,
								onChange: (event) => patch({ parentPhone: event.target.value }),
								required: true
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "البريد الإلكتروني",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "h-12 w-full rounded-2xl border border-ink/15 bg-fg px-3 text-ink outline-none focus:border-gold-ink",
							type: "email",
							autoComplete: "email",
							value: form.email,
							onChange: (event) => patch({ email: event.target.value }),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "الرقم القومي",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "h-12 w-full rounded-2xl border border-ink/15 bg-fg px-3 text-ink outline-none focus:border-gold-ink",
							inputMode: "numeric",
							maxLength: 14,
							value: form.nationalId,
							onChange: (event) => patch({ nationalId: event.target.value }),
							required: true
						})
					})
				] }),
				!user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: mode === "create" ? "كلمة مرور للحساب" : "كلمة المرور",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						type: "password",
						autoComplete: mode === "create" ? "new-password" : "current-password",
						value: form.password,
						onChange: (event) => patch({ password: event.target.value }),
						required: true
					})
				}) : null,
				!user && mode === "enter" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "البريد",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						type: "email",
						autoComplete: "email",
						value: form.email,
						onChange: (event) => patch({ email: event.target.value }),
						required: true
					})
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-gold-ink",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: goldBtn,
					type: "submit",
					disabled: busy || isPending,
					children: busy ? "جارٍ الحفظ…" : user ? "حفظ الاشتراك" : mode === "create" ? "إنشاء الحساب والاشتراك" : "دخول"
				}),
				!user && true ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-2",
					children: GROK_PROVIDERS.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: paperGhost,
						onClick: () => signIn(provider.providerId, { callbackURL: "/join" }),
						children: [
							"المتابعة عبر ",
							provider.label === "Google" ? "جوجل" : "إكس",
							" ثم إكمال البيانات"
						]
					}, provider.providerId))
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						className: "font-semibold text-gold-ink",
						children: "صفحة الدخول"
					})
				})
			]
		})]
	}) });
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-1 text-sm font-semibold",
		children: [label, children]
	});
}
//#endregion
export { JoinPage as component };
