import { t as GRADES } from "./db-BJvgvhpp.mjs";
import { C as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ghostBtn, c as useCurrentUserState, n as Shell, o as goldBtn, t as PhoneCard } from "./shell-C7P0fcYy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BTDtTV9B.js
var import_jsx_runtime = require_jsx_runtime();
var TAGLINE = "العلم يصنع غداً أفضل";
var PHILOSOPHY = "لم تصمَّم هذه المنصة لتكون دليلك للحصول على الدرجة النهائية فقط، بل صُمِّمت لترقى بفهم الطالب لما هو أبعد من ذلك؛ لتبني أساسيات التفكير العلمي الصحيح. فالمعرفة الحقيقية لا تقف عند حدود الصفحة أو ورقة الامتحان، بل تظهر حين يمتلك الطالب القدرة على طرح السؤال الصحيح، وتحليل المعطيات، وربط المفاهيم بما يراه حوله في الواقع. هنا ستجد مساحة للتأمل والتجربة خطوة بخطوة، لتصبح أكثر ثقة في فهمك، وأقدر على مواجهة أي تحدٍ معرفي جديد بعقل منفتح ومنهج واضح.";
var PILLARS = [
	{
		n: "٠١",
		title: "كتب",
		text: "فصول تُقرأ بهدوء: تعريف دقيق، مثال محلول بالأرقام، ثم ما الذي يستحق أن تسأل عنه."
	},
	{
		n: "٠٢",
		title: "حصص",
		text: "سبورة الحصة تتحرك مقطعاً مقطعاً. توقف، ارجع، واكتب الصيغة قبل أن تكمل."
	},
	{
		n: "٠٣",
		title: "امتحانات",
		text: "التصحيح على الخادم. لحظة التسليم تُكتب رسالة الدرجة لرقمك ورقم ولي أمرك."
	}
];
var PROMISES = [
	{
		title: "تجارب عملية",
		text: "كل وحدة تقف على مثال تقدر تحسبه، لا على تعريف معلّق."
	},
	{
		title: "مفاهيم مبسطة",
		text: "اللغة فصيحة وقريبة، من غير ما نختصر العلم اختصاراً يضيّعه."
	},
	{
		title: "تفكير علمي",
		text: "السؤال الصح قبل الإجابة المحفوظة."
	},
	{
		title: "مستقبل أوضح",
		text: "من أولى إعدادي حتى تالتة ثانوي، المنهج متّصل مش متقطع."
	}
];
function EnterLinks() {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "inline-block h-11 w-40 rounded-full bg-surface" });
	if (user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/learn",
		className: goldBtn,
		children: "ادخل منصتك"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/join",
		className: goldBtn,
		children: "اشترك الآن"
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative overflow-hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/media/mentor.jpg",
						alt: "",
						className: "h-full w-full object-cover",
						style: { objectPosition: "center 16%" }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hero-veil absolute inset-0" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "dot-grid absolute inset-0 opacity-40" })
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative mx-auto flex min-h-[88svh] max-w-6xl flex-col justify-end px-4 pt-8 pb-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-2xl rounded-3xl bg-canvas/80 p-5 ring-1 ring-line md:p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/media/logo.jpg",
							alt: "شعار قناة SCI TV",
							className: "h-16 w-auto max-w-full rounded-xl"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-sm font-semibold text-gold",
							children: "معلم الكيمياء · قناة SCI TV"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 text-4xl font-extrabold leading-tight md:text-6xl",
							children: TAGLINE
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-xl text-base leading-relaxed text-muted md:text-lg",
							children: "منصة كيمياء من الصف الأول الإعدادي إلى الصف الثالث الثانوي. كتاب تقرأه، حصة تسير فيها خطوة بخطوة، وامتحان تُكتب درجته رسالة على موبايلك وموبايل ولي أمرك."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterLinks, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/grades",
								className: ghostBtn,
								children: "تصفح الصفوف"
							})]
						})
					]
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-3xl px-4 py-16 md:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold text-gold",
				children: "لماذا بُنيت المنصة"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
				className: "mt-5 font-serif text-xl leading-loose text-fg md:text-2xl",
				children: PHILOSOPHY
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid max-w-6xl gap-px bg-line md:grid-cols-3",
				children: PILLARS.map((pillar) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "bg-canvas px-5 py-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-serif text-3xl text-gold",
							children: pillar.n
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 text-2xl font-bold",
							children: pillar.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted",
							children: pillar.text
						})
					]
				}, pillar.title))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "grades",
			className: "mx-auto max-w-6xl px-4 py-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-gold",
					children: "المنهج"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 text-3xl font-bold",
					children: "ستة صفوف، خط واحد"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/grades",
					className: "text-sm font-semibold text-gold",
					children: "كل الوحدات"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-8 divide-y divide-line border-y border-line",
				children: GRADES.map((grade, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/grades/$gradeId",
					params: { gradeId: grade.id },
					className: "flex items-start gap-4 py-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-10 font-serif text-2xl text-gold tabular-nums",
							children: String(index + 1).padStart(2, "0")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-lg font-bold",
								children: grade.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-sm leading-relaxed text-muted",
								children: grade.promise
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "hidden text-sm text-muted sm:block",
							children: [grade.units.length, " وحدات"]
						})
					]
				}) }, grade.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-line bg-surface/40",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-gold",
						children: "رسالة الدرجة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 text-3xl font-bold",
						children: "أول ما تسلّم، الرسالة تتكتب"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm leading-relaxed text-muted md:text-base",
						children: "التصحيح يتم على الخادم، لا في المتصفح. بعدها تُنشأ رسالة للطالب وأخرى لولي الأمر فيها الاسم والامتحان والدرجة والتقدير. تجد النص فوراً في صندوق النتائج، مربوطاً بالرقمين اللذين سجّلتهما عند الاشتراك."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-6 grid gap-3 sm:grid-cols-2",
						children: PROMISES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-2xl border border-line px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-bold",
								children: item.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm leading-relaxed text-muted",
								children: item.text
							})]
						}, item.title))
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneCard, {
					kicker: "نموذج الرسالة · الآن",
					body: "SCI | أكاديمية الكيمياء\nالطالب: ———\nالامتحان: الاتزان الكيميائي\nالدرجة: 4 من 5 (80%)\nالتقدير: جيد جداً\nراجع تفسير الإجابات داخل المنصة."
				})]
			})
		})
	] });
}
//#endregion
export { Home as component };
