import { o as __toESM } from "../_runtime.mjs";
import { t as GROK_PROVIDERS } from "./server-CYvelK-S.mjs";
import { C as require_jsx_runtime, X as require_react, b as Navigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as signIn, t as authClient } from "./client-IWHfIGH2.mjs";
import { a as ghostBtn, c as useCurrentUserState, n as Shell, o as goldBtn, r as fieldClass } from "./shell-C7P0fcYy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-BASl3GjX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function authMessage(message) {
	const text = (message ?? "").toLowerCase();
	if (text.includes("invalid") && text.includes("password")) return "البريد أو كلمة المرور غير صحيحة.";
	if (text.includes("password")) return "تحقق من كلمة المرور.";
	if (text.includes("user") || text.includes("found")) return "لا يوجد حساب بهذا البريد. اشترك أولاً.";
	return message || "تعذر الدخول.";
}
function LoginPage() {
	const { user, isPending } = useCurrentUserState();
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-4 py-16 text-muted",
		children: "جارٍ التحقق من الجلسة…"
	}) });
	if (user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/learn" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto grid max-w-md gap-6 px-4 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold text-gold",
				children: "حساب موجود"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-3xl font-bold",
				children: "ادخل إلى منصتك"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-3 rounded-3xl bg-fg p-5 text-ink",
				onSubmit: (event) => {
					event.preventDefault();
					setBusy(true);
					setError(null);
					authClient.signIn.email({
						email: email.trim(),
						password
					}).then((result) => {
						if (result.error) {
							setError(authMessage(result.error.message));
							setBusy(false);
							return;
						}
						window.location.assign("/learn");
					}).catch(() => {
						setError("تعذر الدخول.");
						setBusy(false);
					});
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1 text-sm font-semibold",
						children: ["البريد", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							type: "email",
							autoComplete: "email",
							value: email,
							onChange: (event) => setEmail(event.target.value),
							required: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1 text-sm font-semibold",
						children: ["كلمة المرور", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							type: "password",
							autoComplete: "current-password",
							value: password,
							onChange: (event) => setPassword(event.target.value),
							required: true
						})]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-gold-ink",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: goldBtn,
						type: "submit",
						disabled: busy,
						children: busy ? "جارٍ الدخول…" : "دخول"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2",
				children: GROK_PROVIDERS.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: ghostBtn,
					onClick: () => signIn(provider.providerId, { callbackURL: "/learn" }),
					children: ["المتابعة عبر ", provider.label === "Google" ? "جوجل" : "إكس"]
				}, provider.providerId))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"أول مرة؟",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/join",
						className: "font-semibold text-gold",
						children: "اشترك من هنا"
					})
				]
			})
		]
	}) });
}
//#endregion
export { LoginPage as component };
