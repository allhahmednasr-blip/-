import { a as findUnit, s as getSql } from "./db-BJvgvhpp.mjs";
import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-DpANBPok.mjs";
import { i as parseProfile, n as gradeBand } from "./student-rules-rhA8dadI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/academy.functions-yvvkeZqF.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function mapProfile(row) {
	return {
		fullName: row.full_name,
		gradeId: row.grade_id,
		governorate: row.governorate,
		phone: row.phone,
		parentPhone: row.parent_phone,
		email: row.email,
		nationalId: row.national_id
	};
}
async function deliver(phone, body) {
	const url = process.env.SMS_GATEWAY_URL;
	if (!url) return "recorded";
	try {
		return (await fetch(url, {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				to: phone,
				text: body
			}),
			signal: AbortSignal.timeout(8e3)
		})).ok ? "sent" : "recorded";
	} catch {
		return "recorded";
	}
}
var getProfile_createServerFn_handler = createServerRpc({
	id: "9c65100c1a906b4019b4feb8c5d3dc12df6374b1169ea1b75fe38fda3bea36b3",
	name: "getProfile",
	filename: "src/lib/academy.functions.ts"
}, (opts) => getProfile.__executeServer(opts));
var getProfile = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getProfile_createServerFn_handler, async ({ context }) => {
	const rows = await (await getSql())`
      select full_name, grade_id, governorate, phone, parent_phone, email, national_id
      from student_profiles
      where user_id = ${context.userId}
      limit 1
    `;
	return rows[0] ? mapProfile(rows[0]) : null;
});
var getDesk_createServerFn_handler = createServerRpc({
	id: "1f8f5b90bb94d539386e04765b7d0d083092e4b913facba16efcc3fa0527235b",
	name: "getDesk",
	filename: "src/lib/academy.functions.ts"
}, (opts) => getDesk.__executeServer(opts));
var getDesk = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getDesk_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	const profiles = await sql`
      select full_name, grade_id, governorate, phone, parent_phone, email, national_id
      from student_profiles
      where user_id = ${context.userId}
      limit 1
    `;
	const attempts = await sql`
      select id, exam_id, score, total, created_at::text as created_at
      from exam_attempts
      where user_id = ${context.userId}
      order by id desc
      limit 30
    `;
	const messages = await sql`
      select id, recipient_role, phone, body, exam_id, status, created_at::text as created_at
      from sms_messages
      where user_id = ${context.userId}
      order by id desc
      limit 40
    `;
	return {
		profile: profiles[0] ? mapProfile(profiles[0]) : null,
		attempts: attempts.map((row) => ({
			id: row.id,
			examId: row.exam_id,
			score: row.score,
			total: row.total,
			createdAt: row.created_at
		})),
		messages: messages.map((row) => ({
			id: row.id,
			recipientRole: row.recipient_role,
			phone: row.phone,
			body: row.body,
			examId: row.exam_id,
			status: row.status,
			createdAt: row.created_at
		}))
	};
});
var saveProfile_createServerFn_handler = createServerRpc({
	id: "452e3ca3484ee79cd17be26f9c2a6f1517a7d482dc41a50a6cb439b7d89b5250",
	name: "saveProfile",
	filename: "src/lib/academy.functions.ts"
}, (opts) => saveProfile.__executeServer(opts));
var saveProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveProfile_createServerFn_handler, async ({ context, data }) => {
	const parsed = parseProfile(data);
	if (!parsed.ok) return parsed;
	const profile = parsed.value;
	const sql = await getSql();
	if ((await sql`
      select user_id from student_profiles
      where national_id = ${profile.nationalId} and user_id <> ${context.userId}
      limit 1
    `).length > 0) return {
		ok: false,
		message: "هذا الرقم القومي مسجّل على حساب آخر."
	};
	await sql`
      insert into student_profiles (
        user_id, full_name, grade_id, governorate, phone, parent_phone, email, national_id
      ) values (
        ${context.userId},
        ${profile.fullName},
        ${profile.gradeId},
        ${profile.governorate},
        ${profile.phone},
        ${profile.parentPhone},
        ${profile.email},
        ${profile.nationalId}
      )
      on conflict (user_id) do update set
        full_name = excluded.full_name,
        grade_id = excluded.grade_id,
        governorate = excluded.governorate,
        phone = excluded.phone,
        parent_phone = excluded.parent_phone,
        email = excluded.email,
        national_id = excluded.national_id,
        updated_at = now()
    `;
	return { ok: true };
});
var getExamPaper_createServerFn_handler = createServerRpc({
	id: "380d6cce1ac70ee1d6a337fbbfebf20c4f58a6d80fdeeddf2ebcd33370094c2f",
	name: "getExamPaper",
	filename: "src/lib/academy.functions.ts"
}, (opts) => getExamPaper.__executeServer(opts));
var getExamPaper = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	return { examId: typeof input === "object" && input && "examId" in input ? String(input.examId) : "" };
}).handler(getExamPaper_createServerFn_handler, async ({ context, data }) => {
	if (!(await (await getSql())`
      select user_id from student_profiles where user_id = ${context.userId} limit 1
    `)[0]) return {
		ok: false,
		message: "أكمل الاشتراك قبل أن تبدأ الامتحان."
	};
	const { buildPaper } = await import("./exam-bank.server-DI9ZM3BF.mjs");
	const paper = buildPaper(data.examId);
	if (!paper) return {
		ok: false,
		message: "هذا الامتحان غير موجود."
	};
	return {
		ok: true,
		paper
	};
});
var submitExam_createServerFn_handler = createServerRpc({
	id: "583620a330d3d57bde93c05c81aa6025586569b9259cb46b218982493410fbff",
	name: "submitExam",
	filename: "src/lib/academy.functions.ts"
}, (opts) => submitExam.__executeServer(opts));
var submitExam = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input || typeof input !== "object") return {
		examId: "",
		answers: {}
	};
	const raw = input;
	const answers = {};
	if (raw.answers && typeof raw.answers === "object") {
		for (const [key, value] of Object.entries(raw.answers)) if (typeof value === "string" && value.length < 400) answers[key] = value;
	}
	return {
		examId: String(raw.examId ?? ""),
		answers
	};
}).handler(submitExam_createServerFn_handler, async ({ context, data }) => {
	const unit = findUnit(data.examId);
	if (!unit) return {
		ok: false,
		message: "هذا الامتحان غير موجود."
	};
	const { gradeAnswers } = await import("./exam-bank.server-DI9ZM3BF.mjs");
	const graded = gradeAnswers(data.examId, data.answers);
	if (!graded) return {
		ok: false,
		message: "تعذر تصحيح الامتحان."
	};
	const sql = await getSql();
	const profileRow = (await sql`
      select full_name, grade_id, governorate, phone, parent_phone, email, national_id
      from student_profiles where user_id = ${context.userId} limit 1
    `)[0];
	if (!profileRow) return {
		ok: false,
		message: "أكمل الاشتراك قبل تسليم الامتحان."
	};
	const profile = mapProfile(profileRow);
	const percent = Math.round(graded.score / graded.total * 100);
	const band = gradeBand(percent);
	const attemptId = (await sql`
      insert into exam_attempts (user_id, exam_id, score, total, answers_json)
      values (${context.userId}, ${data.examId}, ${graded.score}, ${graded.total}, ${JSON.stringify(data.answers)})
      returning id
    `)[0]?.id ?? 0;
	const studentBody = [
		"SCI | أكاديمية الكيمياء",
		`الطالب: ${profile.fullName}`,
		`الامتحان: ${unit.exam.title}`,
		`الدرجة: ${graded.score} من ${graded.total} (${percent}%)`,
		`التقدير: ${band}`,
		"راجع تفسير الإجابات داخل المنصة. الفهم أبعد من الدرجة."
	].join("\n");
	const gradeTitle = (await import("./db-BJvgvhpp.mjs").then((n) => n.n).then((n) => n.a)).findGrade(profile.gradeId)?.title ?? profile.gradeId;
	const parentText = [
		"SCI | أكاديمية الكيمياء",
		`نتيجة: ${profile.fullName}`,
		`الصف: ${gradeTitle}`,
		`الامتحان: ${unit.exam.title}`,
		`الدرجة: ${graded.score} من ${graded.total} (${percent}%)`,
		`التقدير: ${band}`
	].join("\n");
	const targets = profile.phone === profile.parentPhone ? [{
		role: "student",
		phone: profile.phone,
		body: `${studentBody}\n(الرقم نفسه مسجّل لولي الأمر)`
	}] : [{
		role: "student",
		phone: profile.phone,
		body: studentBody
	}, {
		role: "parent",
		phone: profile.parentPhone,
		body: parentText
	}];
	const messages = [];
	for (const target of targets) {
		const status = await deliver(target.phone, target.body);
		const row = (await sql`
        insert into sms_messages (user_id, recipient_role, phone, body, exam_id, status)
        values (${context.userId}, ${target.role}, ${target.phone}, ${target.body}, ${data.examId}, ${status})
        returning id, created_at::text as created_at
      `)[0];
		if (!row) continue;
		messages.push({
			id: row.id,
			recipientRole: target.role,
			phone: target.phone,
			body: target.body,
			examId: data.examId,
			status,
			createdAt: row.created_at
		});
	}
	return {
		ok: true,
		attemptId,
		score: graded.score,
		total: graded.total,
		percent,
		gradeLabel: band,
		review: graded.review,
		messages
	};
});
var reviewAttempt_createServerFn_handler = createServerRpc({
	id: "d713cc8b64247b3626891b634ea520705363eb7d34d8b9e3e49c9fd3edfbfd6a",
	name: "reviewAttempt",
	filename: "src/lib/academy.functions.ts"
}, (opts) => reviewAttempt.__executeServer(opts));
var reviewAttempt = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const id = Number(typeof input === "object" && input && "id" in input ? input.id : input);
	if (!Number.isInteger(id) || id <= 0) throw new Error("محاولة غير صالحة");
	return id;
}).handler(reviewAttempt_createServerFn_handler, async ({ context, data: attemptId }) => {
	const row = (await (await getSql())`
      select exam_id, score, total, answers_json
      from exam_attempts
      where id = ${attemptId} and user_id = ${context.userId}
      limit 1
    `)[0];
	if (!row) return {
		ok: false,
		message: "لا توجد هذه المحاولة في ملفك."
	};
	const answers = JSON.parse(row.answers_json);
	const { gradeAnswers } = await import("./exam-bank.server-DI9ZM3BF.mjs");
	const graded = gradeAnswers(row.exam_id, answers);
	if (!graded) return {
		ok: false,
		message: "تعذر فتح المراجعة."
	};
	const percent = Math.round(row.score / row.total * 100);
	return {
		ok: true,
		examId: row.exam_id,
		score: row.score,
		total: row.total,
		percent,
		gradeLabel: gradeBand(percent),
		review: graded.review
	};
});
//#endregion
export { getDesk_createServerFn_handler, getExamPaper_createServerFn_handler, getProfile_createServerFn_handler, reviewAttempt_createServerFn_handler, saveProfile_createServerFn_handler, submitExam_createServerFn_handler };
