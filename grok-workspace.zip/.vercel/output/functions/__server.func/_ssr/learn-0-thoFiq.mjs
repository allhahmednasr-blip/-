import { o as __toESM } from "../_runtime.mjs";
import { a as findUnit, i as findGrade } from "./db-BJvgvhpp.mjs";
import { C as require_jsx_runtime, X as require_react, b as Navigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as useCurrentUserState, i as formatWhen, n as Shell, o as goldBtn, s as smsStatus, t as PhoneCard } from "./shell-C7P0fcYy.mjs";
import { t as getDesk } from "./academy.functions-BslzFeD2.mjs";
import { r as maskNationalId } from "./student-rules-rhA8dadI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learn-0-thoFiq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LearnPage() {
	const { user, isPending } = useCurrentUserState();
	const [profile, setProfile] = (0, import_react.useState)(void 0);
	const [attempts, setAttempts] = (0, import_react.useState)([]);
	const [messages, setMessages] = (0, import_react.useState)([]);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		let cancel = false;
		getDesk().then((desk) => {
			if (cancel) return;
			setProfile(desk.profile);
			setAttempts(desk.attempts);
			setMessages(desk.messages);
		}).catch((cause) => {
			if (!cancel) setError(cause instanceof Error ? cause.message : "تعذر فتح المنصة");
		});
		return () => {
			cancel = true;
		};
	}, [user?.id]);
	if (isPending || user && profile === void 0 && !error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-4 py-16 text-muted",
		children: "جارٍ فتح ملفك…"
	}) });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/join" });
	if (!profile) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/join" });
	const grade = findGrade(profile.gradeId);
	const latest = messages[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold text-gold",
				children: grade?.short
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "mt-2 text-3xl font-bold",
				children: ["أهلاً ", profile.fullName]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-muted",
				children: [
					profile.governorate,
					" · ",
					profile.phone,
					" · الرقم القومي ",
					maskNationalId(profile.nationalId)
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-gold",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid gap-4 lg:grid-cols-[1.3fr_0.7fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold",
					children: "وحدات صفك"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-4 grid gap-3",
					children: (grade?.units ?? []).map((unit) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-3xl border border-line p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-gold",
								children: unit.kicker
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-bold",
								children: unit.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap gap-2 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/books/$bookId",
										params: { bookId: unit.id },
										className: "inline-flex h-11 items-center rounded-full bg-surface px-4",
										children: "الكتاب"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/lessons/$lessonId",
										params: { lessonId: unit.id },
										className: "inline-flex h-11 items-center rounded-full bg-surface px-4",
										children: "الحصة"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/exams/$examId",
										params: { examId: unit.id },
										className: goldBtn,
										children: "الامتحان"
									})
								]
							})
						]
					}, unit.id))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "grid content-start gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-3xl border border-line p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-bold",
								children: "آخر الدرجات"
							}),
							attempts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: "لم تمتحن بعد. أول تسليم يكتب الرسالة."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-3 grid gap-2",
								children: attempts.slice(0, 4).map((attempt) => {
									const exam = findUnit(attempt.examId);
									const percent = Math.round(attempt.score / attempt.total * 100);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-semibold",
											children: exam?.exam.title ?? attempt.examId
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-muted tabular-nums",
											children: [
												attempt.score,
												"/",
												attempt.total,
												" · ",
												percent,
												"% · ",
												formatWhen(attempt.createdAt)
											]
										})]
									}, attempt.id);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/results",
								className: "mt-4 inline-block text-sm font-semibold text-gold",
								children: "كل النتائج والرسائل"
							})
						]
					}), latest ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneCard, {
						kicker: `${smsStatus(latest.status)} · ${latest.phone}`,
						body: latest.body
					}) : null]
				})]
			})
		]
	}) });
}
//#endregion
export { LearnPage as component };
