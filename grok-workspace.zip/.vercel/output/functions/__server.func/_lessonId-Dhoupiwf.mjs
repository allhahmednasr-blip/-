import { o as __toESM } from "./_runtime.mjs";
import { a as findUnit, i as findGrade } from "./_ssr/db-BJvgvhpp.mjs";
import { C as require_jsx_runtime, X as require_react, y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as Route$1 } from "./_ssr/router-Ci3g2xEk.mjs";
import { n as Shell, o as goldBtn } from "./_ssr/shell-C7P0fcYy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_lessonId-Dhoupiwf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LessonPage() {
	const { lessonId } = Route$1.useParams();
	const unit = findUnit(lessonId);
	const [index, setIndex] = (0, import_react.useState)(0);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!unit || !playing) return;
		const segment = unit.lesson.segments[index];
		if (!segment) return;
		const timer = window.setTimeout(() => {
			setIndex((current) => {
				if (current >= unit.lesson.segments.length - 1) {
					setPlaying(false);
					return current;
				}
				return current + 1;
			});
		}, segment.seconds * 1e3);
		return () => window.clearTimeout(timer);
	}, [
		playing,
		index,
		unit
	]);
	if (!unit) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "px-4 py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-bold",
			children: "الحصة غير موجودة"
		})
	}) });
	const grade = findGrade(unit.gradeId);
	const segment = unit.lesson.segments[index] ?? unit.lesson.segments[0];
	const progress = (index + 1) / unit.lesson.segments.length * 100;
	if (!segment) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-4xl px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/grades/$gradeId",
					params: { gradeId: unit.gradeId },
					className: "text-gold",
					children: grade?.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					" · حصة تفاعلية · ",
					unit.lesson.minutes,
					" دقائق"
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-3xl font-bold",
				children: unit.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mt-6 overflow-hidden rounded-3xl border border-line bg-surface",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/media/mentor.jpg",
						alt: "",
						className: "absolute end-4 bottom-4 h-28 w-20 rounded-2xl object-cover ring-1 ring-gold",
						style: { objectPosition: "center 28%" }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-5 pt-6 pb-6 pe-28 md:px-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-gold",
								children: [
									"مقطع ",
									index + 1,
									" من ",
									unit.lesson.segments.length
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 text-2xl font-bold",
								children: segment.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 max-w-2xl text-base leading-relaxed",
								children: segment.body
							}),
							segment.formula ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								dir: "ltr",
								className: "mt-5 inline-block rounded-2xl bg-canvas px-4 py-3 font-semibold text-gold tabular-nums",
								children: segment.formula
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-1 bg-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-gold",
							style: { width: `${progress}%` }
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: goldBtn,
						onClick: () => setPlaying((value) => !value),
						children: playing ? "إيقاف" : "تشغيل"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex h-11 items-center rounded-full border border-line px-5 text-sm font-semibold",
						onClick: () => {
							setPlaying(false);
							setIndex((current) => Math.max(0, current - 1));
						},
						disabled: index === 0,
						children: "السابق"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex h-11 items-center rounded-full border border-line px-5 text-sm font-semibold",
						onClick: () => {
							setPlaying(false);
							setIndex((current) => Math.min(unit.lesson.segments.length - 1, current + 1));
						},
						disabled: index === unit.lesson.segments.length - 1,
						children: "التالي"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/books/$bookId",
						params: { bookId: unit.id },
						className: "inline-flex h-11 items-center px-3 text-sm text-gold",
						children: "اقرأ الكتاب"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-6 grid gap-2",
				children: unit.lesson.segments.map((item, itemIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						setPlaying(false);
						setIndex(itemIndex);
					},
					className: `flex w-full items-center justify-between rounded-2xl border px-4 py-3 text-start text-sm ${itemIndex === index ? "border-gold bg-surface" : "border-line"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted tabular-nums",
						children: [item.seconds, "ث"]
					})]
				}) }, item.title))
			})
		]
	}) });
}
//#endregion
export { LessonPage as component };
