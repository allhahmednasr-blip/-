import { i as findGrade } from "./_ssr/db-BJvgvhpp.mjs";
import { C as require_jsx_runtime, y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { r as Route$2 } from "./_ssr/router-Ci3g2xEk.mjs";
import { n as Shell } from "./_ssr/shell-C7P0fcYy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_gradeId-BU-ajhY6.js
var import_jsx_runtime = require_jsx_runtime();
function GradePage() {
	const { gradeId } = Route$2.useParams();
	const grade = findGrade(gradeId);
	if (!grade) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-3xl px-4 py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-bold",
			children: "هذا الصف غير موجود"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/grades",
			className: "mt-4 inline-block text-gold",
			children: "عودة إلى الصفوف"
		})]
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold text-gold",
				children: grade.stage
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-3xl font-bold",
				children: grade.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-2xl text-sm leading-relaxed text-muted",
				children: grade.promise
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-8 grid gap-4",
				children: grade.units.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-3xl border border-line p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-gold",
							children: item.kicker
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 text-2xl font-bold",
							children: item.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-2xl text-sm leading-relaxed text-muted",
							children: item.summary
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-wrap gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/books/$bookId",
									params: { bookId: item.id },
									className: "inline-flex h-11 items-center rounded-full bg-surface px-4 font-semibold",
									children: "الكتاب"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/lessons/$lessonId",
									params: { lessonId: item.id },
									className: "inline-flex h-11 items-center rounded-full bg-surface px-4 font-semibold",
									children: "الحصة"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/exams/$examId",
									params: { examId: item.id },
									className: "inline-flex h-11 items-center rounded-full bg-gold px-4 font-bold text-ink",
									children: "الامتحان"
								})
							]
						})
					]
				}, item.id))
			})
		]
	}) });
}
//#endregion
export { GradePage as component };
