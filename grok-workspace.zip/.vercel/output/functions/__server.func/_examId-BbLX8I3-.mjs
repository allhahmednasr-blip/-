import { o as __toESM } from "./_runtime.mjs";
import { a as findUnit, i as findGrade } from "./_ssr/db-BJvgvhpp.mjs";
import { C as require_jsx_runtime, X as require_react, b as Navigate, y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { i as Route$4 } from "./_ssr/router-Ci3g2xEk.mjs";
import { c as useCurrentUserState, n as Shell, o as goldBtn, s as smsStatus, t as PhoneCard } from "./_ssr/shell-C7P0fcYy.mjs";
import { n as getExamPaper, o as submitExam, r as getProfile } from "./_ssr/academy.functions-BslzFeD2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_examId-BbLX8I3-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function clock(total) {
	const minutes = Math.floor(total / 60);
	const seconds = total % 60;
	return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}
function ExamPage() {
	const { examId } = Route$4.useParams();
	const unit = findUnit(examId);
	const { user, isPending } = useCurrentUserState();
	const [gate, setGate] = (0, import_react.useState)("loading");
	const [paper, setPaper] = (0, import_react.useState)(null);
	const [answers, setAnswers] = (0, import_react.useState)({});
	const [left, setLeft] = (0, import_react.useState)(null);
	const [confirming, setConfirming] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [result, setResult] = (0, import_react.useState)(null);
	const lock = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (isPending) return;
		if (!user) {
			setGate("guest");
			return;
		}
		let cancel = false;
		getProfile().then(async (profile) => {
			if (cancel) return;
			if (!profile) {
				setGate("join");
				return;
			}
			const loaded = await getExamPaper({ data: { examId } });
			if (cancel) return;
			if (!loaded.ok) {
				setError(loaded.message);
				setGate("error");
				return;
			}
			setPaper(loaded.paper);
			setLeft(loaded.paper.minutes * 60);
			setGate("ready");
		}).catch((cause) => {
			if (cancel) return;
			setError(cause instanceof Error ? cause.message : "تعذر فتح الامتحان");
			setGate("error");
		});
		return () => {
			cancel = true;
		};
	}, [
		user?.id,
		isPending,
		examId
	]);
	async function finish() {
		if (!paper || lock.current || result) return;
		lock.current = true;
		setBusy(true);
		setError(null);
		try {
			const response = await submitExam({ data: {
				examId,
				answers
			} });
			if (!response.ok) {
				lock.current = false;
				setError(response.message);
				setBusy(false);
				return;
			}
			setResult(response);
			setConfirming(false);
		} catch (cause) {
			lock.current = false;
			setError(cause instanceof Error ? cause.message : "تعذر التسليم");
		} finally {
			setBusy(false);
		}
	}
	(0, import_react.useEffect)(() => {
		if (left == null || result || gate !== "ready") return;
		if (left <= 0) {
			finish();
			return;
		}
		const timer = window.setTimeout(() => setLeft((value) => value == null ? value : value - 1), 1e3);
		return () => window.clearTimeout(timer);
	}, [
		left,
		result,
		gate
	]);
	if (!unit) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "px-4 py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-bold",
			children: "الامتحان غير موجود"
		})
	}) });
	const grade = findGrade(unit.gradeId);
	const answered = paper ? paper.questions.filter((question) => answers[question.id]).length : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-3xl px-4 py-8 pb-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/grades/$gradeId",
					params: { gradeId: unit.gradeId },
					className: "text-gold",
					children: grade?.title
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-bold",
					children: unit.exam.title
				}), left != null && !result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-2xl font-bold text-gold tabular-nums",
					children: clock(left)
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm leading-relaxed text-muted",
				children: [
					unit.exam.count,
					" أسئلة · ",
					unit.exam.minutes,
					" دقائق. التصحيح على الخادم، ثم تُكتب رسالة الدرجة لرقمك ورقم ولي الأمر."
				]
			}),
			isPending || gate === "loading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-muted",
				children: "جارٍ تجهيز ورقة الأسئلة…"
			}) : null,
			gate === "guest" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/login" }) : null,
			gate === "join" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 rounded-3xl border border-line p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "الامتحان يُفتح بعد ما يكتمل الاشتراك." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/join",
					className: `${goldBtn} mt-4`,
					children: "أكمل الاشتراك"
				})]
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm font-semibold text-gold",
				children: error
			}) : null,
			paper && !result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-8 grid gap-6",
				children: paper.questions.map((question, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-3xl border border-line p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-bold",
						children: [
							index + 1,
							". ",
							question.prompt
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid gap-2",
						children: question.choices.map((choice) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-start gap-3 rounded-2xl border border-line px-3 py-3 has-[:checked]:border-gold has-[:checked]:bg-surface",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "radio",
								name: question.id,
								className: "mt-1",
								checked: answers[question.id] === choice,
								onChange: () => setAnswers((current) => ({
									...current,
									[question.id]: choice
								}))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm leading-relaxed",
								children: choice
							})]
						}, choice))
					})]
				}, question.id))
			}) : null,
			result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 grid gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-3xl bg-fg p-5 text-ink",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-semibold text-gold-ink",
								children: "نتيجتك"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-4xl font-extrabold tabular-nums",
								children: [
									result.score,
									"/",
									result.total
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1",
								children: [
									result.percent,
									"% · ",
									result.gradeLabel
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-3",
						children: result.messages.map((message) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneCard, {
							kicker: `${message.recipientRole === "parent" ? "إلى ولي الأمر" : "إلى الطالب"} · ${message.phone} · ${smsStatus(message.status)}`,
							body: message.body
						}, message.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "grid gap-3",
						children: result.review.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-3xl border border-line p-4 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-bold",
									children: [
										index + 1,
										". ",
										item.prompt
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-muted",
									children: ["إجابتك: ", item.chosen ?? "بلا إجابة"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1",
									children: ["الصحيحة: ", item.correct]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 leading-relaxed text-muted",
									children: item.explanation
								})
							]
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/results",
						className: goldBtn,
						children: "صندوق الدرجات والرسائل"
					})
				]
			}) : null
		]
	}), paper && !result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-x-0 bottom-0 z-20 border-t border-line bg-canvas/95 px-4 py-3 backdrop-blur",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-3xl items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted tabular-nums",
				children: [
					"أجبت ",
					answered,
					" من ",
					paper.questions.length
				]
			}), confirming ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-11 rounded-full border border-line px-4 text-sm",
					onClick: () => setConfirming(false),
					children: "رجوع"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: goldBtn,
					disabled: busy,
					onClick: () => void finish(),
					children: busy ? "جارٍ التصحيح…" : "تأكيد التسليم"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: goldBtn,
				onClick: () => setConfirming(true),
				children: "تسليم الامتحان"
			})]
		})
	}) : null] });
}
//#endregion
export { ExamPage as component };
