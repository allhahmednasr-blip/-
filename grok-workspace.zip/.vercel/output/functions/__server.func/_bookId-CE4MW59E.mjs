import { a as findUnit, i as findGrade } from "./_ssr/db-BJvgvhpp.mjs";
import { C as require_jsx_runtime, y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { a as Route$5 } from "./_ssr/router-Ci3g2xEk.mjs";
import { a as ghostBtn, n as Shell, o as goldBtn } from "./_ssr/shell-C7P0fcYy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_bookId-CE4MW59E.js
var import_jsx_runtime = require_jsx_runtime();
function BookPage() {
	const { bookId } = Route$5.useParams();
	const unit = findUnit(bookId);
	if (!unit) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "px-4 py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-bold",
			children: "الكتاب غير موجود"
		})
	}) });
	const grade = findGrade(unit.gradeId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-3xl px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/grades/$gradeId",
					params: { gradeId: unit.gradeId },
					className: "text-gold",
					children: grade?.title
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "mt-4 rounded-3xl bg-fg px-5 py-8 text-ink md:px-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm font-semibold text-gold-ink",
						children: [
							unit.kicker,
							" · كتاب · ",
							unit.book.minutes,
							" دقائق قراءة"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 text-3xl font-extrabold",
						children: unit.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-base leading-relaxed",
						children: unit.summary
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 grid gap-8",
						children: unit.book.sections.map((section) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-xl font-bold",
								children: section.heading
							}),
							section.paragraphs.map((paragraph) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 leading-relaxed",
								children: paragraph
							}, paragraph.slice(0, 24))),
							section.formula ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								dir: "ltr",
								className: "mt-4 rounded-2xl bg-canvas px-4 py-3 text-center font-semibold text-fg tabular-nums",
								children: section.formula
							}) : null,
							section.example ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4 rounded-2xl border border-gold-ink/30 bg-gold/15 px-4 py-3 text-sm leading-relaxed",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold",
									children: "مثال. "
								}), section.example]
							}) : null
						] }, section.heading))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-wrap gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/lessons/$lessonId",
					params: { lessonId: unit.id },
					className: ghostBtn,
					children: "افتح الحصة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/exams/$examId",
					params: { examId: unit.id },
					className: goldBtn,
					children: "ادخل الامتحان"
				})]
			})
		]
	}) });
}
//#endregion
export { BookPage as component };
