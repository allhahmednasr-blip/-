//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CkJJOpuV.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/join",
			"/learn",
			"/login",
			"/results",
			"/books/$bookId",
			"/exams/$examId",
			"/grades/$gradeId",
			"/lessons/$lessonId",
			"/grades/",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-Dlkx1XZk.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/preload-helper-Bcte93I5.js",
			"/assets/link-BeovRVag.js",
			"/assets/lazyRouteComponent-C_7xZPwf.js",
			"/assets/useNavigate-CqZ07dg_.js",
			"/assets/curriculum-CJ4okp2x.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Dlkx1XZk.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D7gFfI0f.js", "/assets/shell-W2fCpwbs.js"]
	},
	"/join": {
		filePath: "/workspace/src/routes/join.tsx",
		children: void 0,
		preloads: [
			"/assets/join-BczGgI55.js",
			"/assets/academy.functions-BRW0GVoG.js",
			"/assets/shell-W2fCpwbs.js",
			"/assets/providers-R25ah5Ot.js",
			"/assets/student-rules-DyUF2GHI.js"
		]
	},
	"/learn": {
		filePath: "/workspace/src/routes/learn.tsx",
		children: void 0,
		preloads: [
			"/assets/learn-DtiAPb0w.js",
			"/assets/academy.functions-BRW0GVoG.js",
			"/assets/shell-W2fCpwbs.js",
			"/assets/student-rules-DyUF2GHI.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-B8AveMrI.js",
			"/assets/shell-W2fCpwbs.js",
			"/assets/providers-R25ah5Ot.js"
		]
	},
	"/results": {
		filePath: "/workspace/src/routes/results.tsx",
		children: void 0,
		preloads: [
			"/assets/results-BGgY0npM.js",
			"/assets/academy.functions-BRW0GVoG.js",
			"/assets/shell-W2fCpwbs.js",
			"/assets/student-rules-DyUF2GHI.js"
		]
	},
	"/books/$bookId": {
		filePath: "/workspace/src/routes/books/$bookId.tsx",
		children: void 0,
		preloads: ["/assets/_bookId-BheDCN0n.js", "/assets/shell-W2fCpwbs.js"]
	},
	"/exams/$examId": {
		filePath: "/workspace/src/routes/exams/$examId.tsx",
		children: void 0,
		preloads: [
			"/assets/_examId-YXfaCKX4.js",
			"/assets/academy.functions-BRW0GVoG.js",
			"/assets/shell-W2fCpwbs.js"
		]
	},
	"/grades/$gradeId": {
		filePath: "/workspace/src/routes/grades/$gradeId.tsx",
		children: void 0,
		preloads: ["/assets/_gradeId-nCy2ikZf.js", "/assets/shell-W2fCpwbs.js"]
	},
	"/lessons/$lessonId": {
		filePath: "/workspace/src/routes/lessons/$lessonId.tsx",
		children: void 0,
		preloads: ["/assets/_lessonId-C19DIpyV.js", "/assets/shell-W2fCpwbs.js"]
	},
	"/grades/": {
		filePath: "/workspace/src/routes/grades/index.tsx",
		children: void 0,
		preloads: ["/assets/grades-BOo5yMQ9.js", "/assets/shell-W2fCpwbs.js"]
	}
} });
//#endregion
export { tsrStartManifest };
