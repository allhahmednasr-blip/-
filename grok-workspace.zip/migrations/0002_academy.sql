create table if not exists student_profiles (
  user_id text primary key,
  full_name text not null,
  grade_id text not null,
  governorate text not null,
  phone text not null,
  parent_phone text not null,
  email text not null,
  national_id text not null unique,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists exam_attempts (
  id serial primary key,
  user_id text not null,
  exam_id text not null,
  score integer not null,
  total integer not null,
  answers_json text not null,
  created_at timestamptz not null default now()
);

create index if not exists exam_attempts_user_idx on exam_attempts (user_id, id desc);

create table if not exists sms_messages (
  id serial primary key,
  user_id text not null,
  recipient_role text not null,
  phone text not null,
  body text not null,
  exam_id text,
  status text not null,
  created_at timestamptz not null default now()
);

create index if not exists sms_messages_user_idx on sms_messages (user_id, id desc);
